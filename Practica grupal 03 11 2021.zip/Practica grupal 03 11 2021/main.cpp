#include <iostream>
#include <conio.h>
#include <fstream>
#include <queue> 
#include "AVL.h"

//GRUPO(SOMOS 2 PORQUE LOS DEMAS NO SE PRESENTARON)
//Uberto Garcia Caceres
//Josue Gabriel Sumare Uscca

using namespace std;
//CODE UBERTO
int fd1(string   key, int n)
{
    int s=key.length();
    return s%n;
}
unsigned int edit_distance(const string& s1, const string& s2)
{
    const size_t len1 = s1.size(), len2 = s2.size();
    vector <vector <unsigned int>> d(len1 + 1, vector <unsigned int >(len2 + 1));
    d[0][0] = 0;
    for(unsigned int i = 1; i <= len1; ++i) d[i][0] = i;
    for(unsigned int i = 1; i <= len2; ++i) d[0][i] = i;

    for(unsigned int i = 1; i <= len1; ++i)
        for(unsigned int j = 1; j <= len2; ++j)
        // note that std::min({arg1 , arg2 , arg3}) works only in C++11 ,
        // for C++98 use std::min(std::min(arg1 , arg2), arg3)
            d[i][j] = min(min(d[i - 1][j] + 1, d[i][j - 1] + 1), (d[i - 1][j - 1] + (s1[i - 1] == s2[j - 1] ? 0 : 1)));
        
    return d[len1][len2];
}

//CODE UBERTO
template<class O, class K,  int (*fd)(string ,int)>
class Hash
{
   private:
        AVL_Tree<O>tree[11];
   public:
        Hash(){};
        void Add(O obj, K key)
        { 
            int pos = fd(key,11);
            tree[pos].Add(obj); 
        }
        AVL_Tree<O> Arbolretornar(int i){
            return tree[i];
        }
    //   void Delete(K key){   }
    //   O find(K key){   }
};
void correccion(Hash<string,string,fd1> &input, Hash<string,string,fd1> &dictionary){
    list<string>in;
    list<string>di;
    for(int i=0; i<11; i++){
        list<string>b = input.Arbolretornar(i).elementos();
        for(auto it1 = begin(b); it1 != end(b); ++it1 ){
            in.push_back(*it1);
        }
        list<string>d = dictionary.Arbolretornar(i).elementos();
        for(auto it2 = begin(d); it2 != end(d); ++it2 ){
            di.push_back(*it2);
        }
    }
    string result="";
    for( auto it = begin(in); it!=end(in); ++it){  
        bool c = false;
        for( auto it2 = begin(di); it2 != end(di); ++it2 ){
            if(*it==*it2){
                c=true;
                break;
            }
        }
        if(!c){
            queue<string> posibles;
            cout<<"Palabra '"<<*it<<"'no encontrada en el diccionario"<<endl;
            for(auto it2 = begin(di); it2 != end(di); ++it2 ){
                if(edit_distance(*it, *it2)<3){
                    posibles.push(*it2);
                }            
            }
            if(!posibles.empty()){
                cout<<"Posibles correcciones: "<<endl;
                int z=0;
                int e=0;
                for(;z<posibles.size(); z++){
                    cout<<posibles.front()<<" - "<<z<<endl;
                    posibles.push(posibles.front());
                    posibles.pop();
                }
                cout<<"Escriba por cual desea reemplazar: ";cin>>e;
                while(e>=z||0>e){
                    cout<<"Escriba por favor uno de los numeros antes mencionados: ";cin>>e;
                }
                if(e!=0){
                    for(;e>0;e--){
                        posibles.push(posibles.front());
                        posibles.pop();
                    }
                }
                cout<<"Hecho, reemplazando por: "<<posibles.front()<<endl;
                result+=posibles.front()+" ";
            }
            else{
                cout<<"Posibles correcciones: No hay en el diccionario"<<endl;
            }
        }
        else{
            result+=*it+" ";
        }
    }
    ofstream archivo;
    archivo.open("output.txt");
    archivo<<result;
    archivo.close();
    cout<<"\nArchivo output.txt creado con exito"<<endl;
}
int main()
{
    string palabra;
    string palabra2;
    Hash<string, string, fd1> Diccionario;
    Hash<string, string, fd1> Input;
    //Intoduce en la variable palabra el diccionario
    ifstream diccionario("ENGLISH.txt");
    while(!diccionario.eof()) {
        diccionario >> palabra;
        Diccionario.Add(palabra,palabra);
    }
    diccionario.close();
    ifstream input1("texto1.txt");
    while(!input1.eof()) {
        input1 >> palabra2;
        Input.Add(palabra2,palabra2);
    }
    input1.close();
    correccion(Input,Diccionario);
    cout<<"hELLOO"<<endl;
    return 1;
};