#include "iostream"
#include "Node.h"
using namespace std;
template<typename T>
class AVL{
    private:

        Node<T>*m_pHead;
    
        void preOrden(Node<T>*pAux){
            if(!pAux)return;
            cout<<pAux->value<<" -> FE: "<<pAux->FE<<endl;
            preOrden(pAux->m_pSon[0]);
            preOrden(pAux->m_pSon[1]);
        }
    public:

        AVL(){
            this->m_pHead=0;
        }
        void Add(T value){
            if(!this->m_pHead){
                this->m_pHead=new Node<T>(value);
                return;
            }
            Node<T>*pAux=this->m_pHead;
            while(pAux->m_pSon[pAux->value<value]){
                if(pAux->value==value)return;
                pAux=pAux->m_pSon[pAux->value<value];
            }
            pAux->m_pSon[pAux->value<value]=new Node<T>(value);
            pAux->m_pSon[pAux->value<value]->m_pSon[2]=pAux;
            pAux=pAux->m_pSon[pAux->value<value];
            while(pAux->m_pSon[2]){
                (pAux->value<pAux->m_pSon[2]->value)?pAux->m_pSon[2]->FE--:pAux->m_pSon[2]->FE++;
                if(!pAux->m_pSon[2]->value)return;
                pAux=pAux->m_pSon[2];
            }

        }
        void preOrden(){
            this->preOrden(this->m_pHead);
        }

        
};