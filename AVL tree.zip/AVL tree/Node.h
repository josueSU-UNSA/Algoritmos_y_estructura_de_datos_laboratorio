template<typename T>
class Node{
    public:

        T value;
        int FE;
        Node<T>*m_pSon[3];
    
    public:

        Node(T value){
            this->value=value;
            this->FE=0;
            this->m_pSon[0]=this->m_pSon[1]=this->m_pSon[2]=0;
        }

};
