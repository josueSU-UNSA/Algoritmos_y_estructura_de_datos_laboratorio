#include<iostream>
#include<conio.h>
#include "AVL.h"

using namespace std;

int main(){/*
    Node<int>nodoAux(4);
    (!nodoAux.m_pSon[0])?cout<<"Es nullptr"<<endl:cout<<"No es nullptr"<<endl;
    (!nodoAux.m_pSon[1])?cout<<"Es nullptr"<<endl:cout<<"No es nullptr"<<endl;
    (!nodoAux.m_pSon[2])?cout<<"Es nullptr"<<endl:cout<<"No es nullptr"<<endl;
    cout<<nodoAux.value<<endl;*/
    AVL<float>test;
    test.Add(30);
    test.Add(17);
    test.Add(35);
    test.Add(16);
    test.Add(18);
    test.Add(34);
    test.Add(38);
    test.Add(33);
    test.Add(32);
    test.Add(16.5);

    test.preOrden();
    getch();
    return 0;
}