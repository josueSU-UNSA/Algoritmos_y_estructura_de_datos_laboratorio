#include "AVLTree.h"
#include<iostream>
#include <fstream>
#include <conio.h>
#include <stdlib.h>
#include "AVL.h"
using namespace std;
void test2(int n)
{ 

    
}
int main(){
    //srand (10); 
    //const int N = 10;
    AVLTree<int>test;
    int arr[]={57,98,39,12,1,15,19,13,21,14,27,31,9};
    for(int i=0;i<13;i++)test.Add(arr[i]);
    //test.graficar();
    /*
    AVL_Tree<int>avlPreHecho;//la libreria AVL.h
    

    int ij = 100;
    /*while(i<1000000)B
    {
       test2(i);
       i = i*10;   
    }
    for(int i=0;i<ij;i++)//del 0 al 999
      { 
        //cout<<i<<endl;
        avlPreHecho.Add(i);
        test.Add(i);
      }
    */
/*        
    test.Add(500);
    test.Add(30);
    test.Add(650);
    test.Add(100);
    test.Add(550);
    test.Add(800);
    test.Add(700);
    test.Add(900);
    test.Add(680);*/
    test.graficar();
    //test.print();
    
    
    
    
    system("pause");
    return 0;
}
