
//--------------------------------------------------------------------------------------------------------
// -----------------------------SPARSE MATRIX-------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------- 
 #include<iostream>
 #include<set>
 using namespace std;
 
 template<class T>
 class Cell
 {
      public:
         int       m_Fil;//EN Q FILA SE UBICARA
         int       m_Col;//EN Q COLUMNA SE UBICARA
         Cell<T> * m_SigFil;//PUNTERO ALA SIGUIENTE FILA "↓"
         Cell<T> * m_SigCol; //PUNTERO A LA SGTE COLUMNA "->"
         T         m_Dato; //EL DATO A INSERTAR
      public:
         Cell(T d, int f, int c)//DEBEMOS PASAR EL NUM DE FILA Y COLUMNA
         {
            m_Fil=f;//INICIALIZAMOS EL NUM DE FILA
            m_Col=c;//INICIALIZAMOS EL NUM DE COL
            m_SigFil=0;//AL CREAR LA SIG FILA SERA NULL
            m_SigCol=0;//AL CREAR LA SIG COL SERA NULL
            m_Dato=d; //INICIALIZAMOS EL DATO 
         }  
         
         Cell()//CREACION DE UNA CELDA POR DEFECTO POR SI ACASO
         {
            m_Fil=0;
            m_Col=0;
            m_SigFil=0;
            m_SigCol=0;
         }
 };
 

 
template<class T, const int n_Fil=10, const int n_Col=10>//PASAMOS EL NUM FILAS Y COLUMNAS ADEMAS DEL TIPO
class Sparce{
   // PODEMOS DECIR Q EL INSERT DE UNA MATRIZ ESPARSA FUNCIONA COMO EL DE UNA LISTA ENLAZADA
   private:
      Cell<T>     *m_Fil[n_Fil];//CREAMOS UNA ARRAY DE PUNTEROS YA Q LOS ARRAYS GUARDARAN PUNTEROS A CELDAS
      Cell<T>     *m_Col[n_Col];//ARRAY Q GUARDARAN PUNTEROS A LOS NODOS
   public:

      Sparce()
      {

         for(int i=0;i<n_Fil;i++)//INICIALIZA TODO EL ARRAY FILA EN NULL
            m_Fil[i]=0; 
      
         for(int i=0;i<n_Col;i++)//INICALIZA TODO EL ARRAY COLUMNA EN NULL
            m_Col[i]=0; 

      }
      //NOS DEJARA EL PUNTERO DOBLE EN LA COLUMNA DESEADA
      //NOS DEJARA EL PUNTERO DOBLE EN EL LUGAR Q QUEREMOS HACER 
      //EL INSERT
      //COMO HALLAREMOS LA COLUMNA Q SE QUIERE
      //DEBEMOS MOVERNOS DESDE EL ARRAY DE FILAS 
      //EMULANDO LAS ITERACIONES DE UNA LISTA ENLAZADA
      //--------------BUSCAMOS DE FORMA HORIZONTAL-------
      bool find_col(int f, int c, Cell<T> ** & q)// 
      {
         q =  &m_Fil[f];//COMO MOVEREMOS LA COLUMNA 
                        //DEJAREMOS EL PUNTERO  "q"
                        //Q SE MUEVE POR LAS FILAS 
                        //EN LA FILA A INSERTAR
         while(*q)
         {
            if((*q)->m_Col == c) return true;//LO Q QUIERE DECIR
                                             //YA EXISTE UNA CELDA EN 
                                             //ESA POSICION
                                             //SI LA COLUMNA DONDE SE QUEDA
                                             //EL PTRO
                                             //ES IGUAL A LA COLUMNA
                                             //DONDE SE INSERTARA
                                             //ES LA POSICION DED COLUMNA
                                             //Q BUSCAMOS

            if((*q)->m_Col > c)  return false;//LO Q PASA ACA ES 
                                                //QUIERES INSERTAR EN MEDIO
                                                //DE DOS CELDAS
                                                //Y LA SGTE CELDA ESTA ADELANTE
                                                //DEL Q SE QUIERE INSERTAR

            q  = &((*q)->m_SigCol);//RECORRE LAS COLUMNAS
         }

         return false;

     }
      //NOS DEJARA EL PUNTERO DOBLE EN EL LUGAR Q QUEREMOS HACER 
      //EL INSERT
      //--------------BUSCAMOS DE FORMA VERTICAL-------
      bool find_fil(int f, int c, Cell<T> ** & p)
      {
         p =  &m_Col[c];//UBICAMOS EL PUNTERO P
                        //EN LA COLUMNA 
                        //E ITERAREMOS DE FORMA VERTICAL
                        //PARA HALLAR LA FILA
         while(*p){

           if((*p)->m_Fil == f) return true;
           if((*p)->m_Fil > f)  return false;
           p  = &((*p)->m_SigFil); 

         }
       
       return false;
     }
      //-------------------------------------------------------
      //----FUNCION INSERT LA MAS IMPORTANTE-------------------
      void Insert(T d, int f, int c){
          
         Cell<T> **p;//ES DONDE SE INSERTARA EN CUESTION DE FILA
         Cell<T> **q;//ES DONDE SE INSERTARA EN CUESTION DE COLUMNA
         bool  a = find_fil(f,c,p);
         bool  b = find_col(f,c,q);
         if(!a && !b){//SI HAY ALGUIEN ESA COLUMNA Y FILA ENTONCES NO INSERTA
                        //SI HAY UN FALSE ES XQ HAY UNA CELDA POSTERIOR A ESTA COLUMNA Y/O FILA
                        //O TMBN SI ESTAS SON NULL ENTONCES SOLO UBICARA
            Cell<T> * pNuevo = new Cell<T>(f,c,d);//CREAMOS NUESTRA NUEVA CELDA
            pNuevo->m_SigFil= *p;//HACEMOS Q EL PTRO NUEVO APUNTARA A NUESTRA SGTE FILA
                                 //YA Q RECORDEMOS Q SE INSERTA EN MEDIO
                                 //YA SEA DE UNA CELDA Y UN NULL
                                 //O VICEVERSA
            pNuevo->m_SigCol= *q;//HACEMOS Q LA SGTE COLUMNA APUNTE 
                                 //ALA POSTERIOR COLUMNA
                                 //YA Q SE INSERTA EN MEDIO DE IGUAL
                                 //MANERA

            *p = *q = pNuevo;//UNA VEZ YA SALVADAS LAS CONEXIONES CON LOS SIGUIENTES CELDAS
                              //YA SEA NULL O UNA CELDA
                              //PODEMOS UBICAR EN LA RESPECTIVA UBICACION
          
         }    
          
      }
      
      void Print()
      {
         Cell<int> ** q;
         for(int i=0;i<n_Fil;i++){

            for(int j=0;j<n_Col;j++){

               if(find_fil(i,j,q))
                  cout<<(*q)->m_Dato<<" ";
               else cout<<"0 ";

           }

           cout<<endl;

         }
          
      
      }
 };
 
 
 
 int main()
 {
 
  Sparce<int> M;
  for(int i=0;i<10;i++)
     M.Insert(1,i,i);
  M.Print();
  
//   set<int, set<int ,string>>  M;
  
  
   system("pause");
   return 1;
 };
