#include<iostream>
#include<list>
#include<iterator>

// Heaps (Binary Heap , Binomial Heap, Fibonacci Heap) // Cormen
// Grafos  (Matrices de Adyasencia,Matrices de Adyasencia etiquetada, Listas de adyasencia)
// Algoritmo sobre grafos 
   // floy, Arboles de expación mínima (Prim, Kruskall), warssall, Disjktra, coloreado de grafos, grafor bipartitos. // Cormen
// Arboles B,B*, patricia y digitales. // Cormen
   
using namespace std;


template<class O, class K,  int (*fd)(string ,int),const int size = 11 >
class Hash
{
   public:
      list<O>  m_list[size];//Type O q es el tipo de Objetos a insertar en la tabla hash
   public:
       Hash(){};
       void Add(O obj, K key)
       { 
           int pos = fd(key,size);
           //cout<<"Se insertó elemento en la posición:"<<pos<<endl;
           m_list[pos].push_back(obj); 
           
       }
       void print(){
           list<O>aux;
           for(int i=0;i<m_list->size();i++){
               aux=m_list[i];
               typename list<O>::iterator ptrAux1;
               for(ptrAux1=m_list[i].begin();ptrAux1!=m_list[i].end();ptrAux1++){
                    cout<<*ptrAux1<<std::endl<<"|"<<std::endl<<"∨"<<std::endl;
               }
               ptrAux1++;
               cout<<*ptrAux1<<std::endl<<"|"<<std::endl<<"∨"<<std::endl;
           }
       }
    //   void Delete(K key){   }
        bool find(O obj,K key){//O
            int i=fd(key,size);
            list<O>aux=m_list[i];
            typename list<O>::iterator ptrAux;
            for(ptrAux=aux.begin(); ptrAux !=aux.end();ptrAux++){
                if(*ptrAux==obj)return true;
            }
            ptrAux++;
            if(*ptrAux==obj)return true;
            return false;
            
        }
        int findIndex(K key){//O
            int i=fd(key,size);
            return i;
            
        }
};



int fd1(string   key, int n)
{
    int s=0;
    char * k = (char*)key.c_str();
    while(*k)
    {
      s+=int(*k);
      k++;   
    }
    return s%n;
}

class Persona
{
public:
    string codigo;
    string Nombre;
public:    
    Persona(){};
};

int main()
{
    // Hash<string, string, fd1> Tabla;
    
    
    // Tabla.Add(string("juan"),string("2312"));
    // Tabla.Add(string("Luis"),string("2712"));
    // Tabla.Add(string("Carlos"),string("1372"));
    // Tabla.Add(string("Maria"),string("2381"));
    // Tabla.Add(string("Lucifer"),string("1832"));
    // //Tabla.print();
    // string aux="Lucifer";
    // string auxKey="1832";
    // Tabla.print();
    // (Tabla.find(aux,auxKey))?cout<<"Se encontro"<<endl:cout<<"No se encontro"<<endl;
    // cout<<"Indice "<<Tabla.findIndex("1372")<<endl;
    // // typename list<O>::iterator ptrAux;
    // //         for(ptrAux=aux.begin(); ptrAux !=aux.end();ptrAux++){
    // //             if(*ptrAux==obj)return true;
    // //         }
    // //         ptrAux++;
    // typename list<string>::iterator ptrAux=Tabla.m_list[7].begin();
    // cout<<"The value of index 8 from my hash table is "<<*(ptrAux)<<endl;
    // cout<<"I said hello"<<endl;
    //Hash<string, string, fd1> Example;
    return 1;
};


