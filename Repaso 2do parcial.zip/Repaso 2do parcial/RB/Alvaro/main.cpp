#include <iostream>
#include <stdlib.h>
#include <fstream>
#include<conio.h>
#include<math.h>
#include "RB.h"
#include <chrono>

using namespace std;

int main(){
    //test de funcion con operador ternario

    srand (10); 

    int j= 1000;
    RB_Tree<int>test;
    // // test.Add(rand()%i);
    // for(int i=0;i<15;i++){
    //     int a=rand()%j;
    //     test.insert(a);
    //     cout<< a<<endl;
    // }
    test.insert(4);
    test.insert(10);
    test.insert(8);
    test.print();
    
    // test.Print("grafico.dot");
    
/*
    test.Add(205);
    test.Add(9990);
    test.Add(352);
    */
    // test.print();
    /*
    cout<<"El padre de 90 es: "<<test.find(90)->m_pSig[2]->value<<endl;
    cout<<"El padre de 130 es: "<<test.find(130)->m_pSig[2]->value<<endl;
    cout<<"El padre de 180 es: "<<test.find(180)->m_pSig[2]->value<<endl;
    cout<<"El padre de 300 es: "<<test.find(300)->m_pSig[2]->value<<endl;
    cout<<"El padre de 200 es: "<<test.find(200)->m_pSig[2]->value<<endl;
    cout<<"El padre de 100 es: "<<test.find(100)->m_pSig[2]->value<<endl;
    cout<<"El padre de 150 es: "<<test.find(150)->m_pSig[2]<<endl;

    cout<<"El hermano de 90 es: "<<test.hermano(90)<<endl;
    cout<<"El hermano de 130 es: "<<test.hermano(130)<<endl;
    cout<<"El hermano de 180 es: "<<test.hermano(180)<<endl;
    cout<<"El hermano de 300 es: "<<test.hermano(300)<<endl;
    cout<<"El hermano de 200 es: "<<test.hermano(200)<<endl;
    cout<<"El hermano de 100 es: "<<test.hermano(100)<<endl;
    //cout<<"El hermano de 150 es: "<<test.hermano(150)<<endl;
    cout<<"El tio de 90 es: "<<test.tio(90)<<endl;
    cout<<"El tio de 130 es: "<<test.tio(130)<<endl;
    cout<<"El tio de 180 es: "<<test.tio(180)<<endl;
    cout<<"El tio de 300 es: "<<testAdd_case_1(pAux);
    //cout<<"El tio de 200 es: "<<test.tio(200)<<endl;
    //cout<<"El tio de 100 es: "<<test.tio(100)<<endl;
    cout<<"El abuelo de 90 es: "<<test.abuelo(90)<<endl;
    cout<<"El abuelo de 130 es: "<<test.abuelo(130)<<endl;
    cout<<"El abuelo de 180 es: "<<test.abuelo(180)<<endl;
    cout<<"El abuelo de 300 es: "<<test.abuelo(300)<<endl;
    
    */

/*
    cout<<"El padre de "<< 150<<" "<<test.find(150)->m_pSig[2]<<endl;
    cout<<"El padre de "<< 100<<" "<<test.find(100)->m_pSig[2]->value<<endl;
    cout<<"El padre de "<< 550<<" "<<test.find(550)->m_pSig[2]->value<<endl;
    cout<<"El padre de "<< 20<<" "<<test.find(20)->m_pSig[2]->value<<endl;
    cout<<"El padre de "<< 400<<" "<<test.find(400)->m_pSig[2]->value<<endl;
    cout<<"El padre de "<< 1000<<" "<<test.find(1000)->m_pSig[2]->value<<endl;
    cout<<"El padre de "<< 890<<" "<<test.find(890)->m_pSig[2]->value<<endl;
    cout<<"El padre de "<< 770<<" "<<test.find(770)->m_pSig[2]->value<<endl;
*/

    system("pause");
    return 0;

}