#include <iostream>
#include <cmath>
#include <fstream>
#include "RB.h"
using namespace std;

int test6();
int main(){
    
    RB_Tree<int> rb;
    rb.insert(10);
    rb.insert(2);
    rb.insert(20);
    rb.insert(15);
    rb.print();
    ofstream vamos("arbolito.dot");
    rb.Print(vamos);
    rb.print();

    return 0;
}

