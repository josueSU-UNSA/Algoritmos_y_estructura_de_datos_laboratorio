#include <iostream>
using namespace std;

template <typename T>
class NodoRB
{
private:
    T mp_dato;
    NodoRB<T> *mp_son[3];
    string color;
    template <typename U>
    friend class RB_Tree;

public:
    NodoRB()
    {
        mp_dato = 0;
        mp_son[0] = NULL;
        mp_son[1] = NULL;
        mp_son[2] = NULL;
        color = "";
    }
    NodoRB(T d)
    {
        mp_dato = d;
        mp_son[0] = NULL;
        mp_son[1] = NULL;
        mp_son[2] = NULL;
        color = "red";
    }
};

template <typename T>
class RB_Tree
{
private:
    NodoRB<T> *mp_root;
    void printHelper(NodoRB<T> *p)
    {
        if (!p)
            return;
        cout << "\t" << p << "    : " << p->mp_dato << "  con color  " << p->color << endl;
        cout << p->mp_son[0] << "\t\t" << p->mp_son[1] << endl;
        printHelper(p->mp_son[0]);
        //cout<<p->mp_dato<<endl;
        printHelper(p->mp_son[1]);
    }
    bool insertHelper(T d, NodoRB<T> *&p, NodoRB<T> *padre)
    {
        if (!p)
        {
            p = new NodoRB<T>(d);
            p->mp_son[2] = padre;
            insercion_caso1(p);
        }
        padre = p;
        if (p->mp_dato == d)
            return false;
        return insertHelper(d, p->mp_son[p->mp_dato < d], padre);
    }

public:
    RB_Tree()
    {
        mp_root = NULL;
    }
    bool insert(T d)
    {
        return insertHelper(d, mp_root, NULL);
    }
    void print()
    {
        printHelper(mp_root);
    }
    NodoRB<T> *minimum()
    {
        NodoRB<T> *min = mp_root;
        while (min->mp_son[0])
        {
            min = min->mp_son[0];
        }
        return min;
    }
    NodoRB<T> *abuelo(NodoRB<T> *n)
    {
        if ((n != NULL) && (n->mp_son[2] != NULL))
            return n->mp_son[2]->mp_son[2];
        else
            return NULL;
    }

    NodoRB<T> *tio(NodoRB<T> *n)
    {
        NodoRB<T> *a = abuelo(n);
        if (n->mp_son[2] == a->mp_son[0])
            return a->mp_son[1];
        else
            return a->mp_son[0];
    }

    NodoRB<T> *hermano(NodoRB<T> *n)
    {
        if (n == n->mp_son[2]->mp_son[0])
            return n->mp_son[2]->mp_son[1];
        else
            return n->mp_son[2]->mp_son[0];
    }

    void insercion_caso1(NodoRB<T> *n)
    {
        if (n->mp_son[2] == NULL)
            n->color = "black";
        else
            insercion_caso2(n);
    }
    void insercion_caso2(NodoRB<T> *n)
    {
        if (n->mp_son[2]->color == "black")
            return; /* Árbol válido. */
        else
            insercion_caso3(n);
    }
    void insercion_caso3(NodoRB<T> *n)
    {
        NodoRB<T> *t = tio(n), *a;
        if ((t != NULL) && (t->color == "red"))
        {
            n->mp_son[2]->color = "black";
            t->color = "black";
            a = abuelo(n);
            a->color = "red";
            insercion_caso1(a);
        }
        else
        {
            insercion_caso4(n);
        }
    }
    void insercion_caso4(NodoRB<T> *n)
    {
        NodoRB<T> *a = abuelo(n);

        if ((n == n->mp_son[2]->mp_son[1]) && (n->mp_son[2] == a->mp_son[0]))
        {
            rotar_izda(n->mp_son[2]);
            n = n->mp_son[0];
        }
        else if ((n == n->mp_son[2]->mp_son[0]) && (n->mp_son[2] == a->mp_son[1]))
        {
            rotar_dcha(n->mp_son[2]);
            n = n->mp_son[1];
        }
        insercion_caso5(n);
    }
    void insercion_caso5(NodoRB<T> *n)
    {
        NodoRB<T> *a = abuelo(n);

        n->mp_son[2]->color = "black";
        a->color = "red";
        if ((n == n->mp_son[2]->mp_son[0]) && (n->mp_son[2] == a->mp_son[0]))
        {
            rotar_dcha(a);
        }
        else
        {
            rotar_izda(a);
        }
    }
    void rotar_izda(NodoRB<T> *p)
    {
        NodoRB<T> **aux = &mp_root;
        if (p->mp_son[2] != NULL && p->mp_son[2]->mp_son[1] == p)
            aux = &(p->mp_son[2]->mp_son[1]);
        else if (p->mp_son[2] != NULL && p->mp_son[2]->mp_son[0] == p)
            aux = &(p->mp_son[2]->mp_son[0]);

        *aux = p->mp_son[1];
        (*aux)->mp_son[2] = p->mp_son[2];
        p->mp_son[2] = *aux;
        p->mp_son[1] = (*aux)->mp_son[0];
        (*aux)->mp_son[0] = p;

        if (p->mp_son[1] != NULL)
            p->mp_son[1]->mp_son[2] = p;
    }
    void rotar_dcha(NodoRB<T> *p)
    {
        NodoRB<T> **aux = &mp_root;
        if (p->mp_son[2] != NULL && p->mp_son[2]->mp_son[1] == p)
            aux = &(p->mp_son[2]->mp_son[1]);
        else if (p->mp_son[2] != NULL && p->mp_son[2]->mp_son[0] == p)
            aux = &(p->mp_son[2]->mp_son[0]);

        *aux = p->mp_son[0];
        (*aux)->mp_son[2] = p->mp_son[2];
        p->mp_son[2] = *aux;
        p->mp_son[0] = (*aux)->mp_son[1];
        (*aux)->mp_son[1] = p;

        if (p->mp_son[0] != NULL)
            p->mp_son[0]->mp_son[2] = p;
    }

    // void remove(T x)
    // {
    //     NodoRB<T> *aux = mp_root;
    //     while (aux != NULL)
    //     {
    //         if (aux->mp_dato == x)
    //         {
    //             break;
    //         }
    //         aux = aux->mp_son[x > (aux->mp_dato)];
    //     }
    //     if (aux != NULL)
    //     {
    //         if (aux->mp_son[0] && aux->mp_son[1])
    //         {
    //             NodoRB<T> *aux2 = aux->mp_son[1];
    //             string c=aux->color;
    //             while (aux2->mp_son[0] != NULL)
    //             {
    //                 aux2 = aux2->mp_son[0];
    //             }
    //             aux->mp_dato = aux2->mp_dato;
    //             if (aux2->mp_son[1])
    //             {
    //                 NodoRB<T> *aux3 = aux2;
    //                 string col=aux2->color;
    //                 aux2 = aux2->mp_son[2];
    //                 aux2->mp_son[aux2->mp_dato < aux3->mp_dato] = aux3->mp_son[1];
    //                 aux3 = aux3->mp_son[1];
    //                 aux3->mp_son[2] = aux2;
    //                 aux3->color=col;
    //             }
    //             else
    //             {
    //                 NodoRB<T> *aux3 = aux2;
    //                 aux2 = aux2->mp_son[2];
    //                 aux2->mp_son[aux2->mp_dato < aux3->mp_dato] = NULL;
    //             }
    //         }
    //         else if (aux->mp_son[0] != NULL)
    //         {
    //             NodoRB<T> *aux2 = aux;
    //             string c=aux->color;
    //             aux = aux->mp_son[2];
    //             aux->mp_son[aux->mp_dato < aux2->mp_dato] = aux2->mp_son[0];
    //             aux2 = aux2->mp_son[0];
    //             aux2->mp_son[2] = aux;
    //             aux2->color=c;
    //         }
    //         else if (aux->mp_son[1] != NULL)
    //         {
    //             NodoRB<T> *aux2 = aux;
    //             string c=aux->color;
    //             aux = aux->mp_son[2];
    //             aux->mp_son[aux->mp_dato < aux2->mp_dato] = aux2->mp_son[1];
    //             aux2 = aux2->mp_son[1];
    //             aux2->mp_son[2] = aux;
    //             aux2->color=c;
    //         }
    //         else
    //         {
    //             NodoRB<T> *aux2 = aux;
    //             aux = aux->mp_son[2];
    //             aux->mp_son[aux->mp_dato < aux2->mp_dato] = NULL;
    //         }
    //     }
    // }
    NodoRB<T>* Search(T d){
        NodoRB<T> *aux=mp_root;
        while(aux!=NULL){
            if(aux->mp_dato==d){
                return aux;
            }
            aux=aux->mp_son[d>aux->mp_dato];
        }
        cout<<"Elemento no encontrado"<<endl;
        return NULL;
    }
    void Print(ostream &os) {
        os << "digraph G {" << endl;
        os << "label= \"Red black Tree\";" << endl;
        os << "node [shape = record];" << endl;
        Print(mp_root, os);
        os << "}" << endl;
        system("dot -Tjpg -O arbolito.dot");
        system("arbolito.dot.jpg");
    }
    void Print(NodoRB<T> * r, ostream &os)
    {
        if(!r) return;
        os << r->mp_dato << "[label = " << r->mp_dato;
        if(r->mp_son[2])
            os<<" | "<<r->mp_son[2]->mp_dato;
        os<<",fontcolor=white,style=filled,fillcolor="<<r->color<<"];" << endl;
        if(r->mp_son[0]){
            os << r->mp_dato << "->" <<r->mp_son[0]->mp_dato<<";"<<endl;
        }
        if(r->mp_son[1]){
            os << r->mp_dato << "->" <<r->mp_son[1]->mp_dato<<";"<<endl;
        }
        Print(r->mp_son[0], os);
        Print(r->mp_son[1], os);
    }
};
