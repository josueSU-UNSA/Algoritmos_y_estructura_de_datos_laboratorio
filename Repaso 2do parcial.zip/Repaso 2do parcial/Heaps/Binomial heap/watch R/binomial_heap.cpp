#include <iostream>
#include <list>
#include <time.h>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <math.h>

using namespace std;
//----------------------------IMPRESION MAS CONFUSA--------------------------------


unsigned long hex2dec(string hex)
{
    unsigned long result = 0;
    for (int i=0; i<hex.length(); i++) {
        if (hex[i]>=48 && hex[i]<=57)
        {
            result += (hex[i]-48)*std::pow(16,hex.length()-i-1);
        } else if (hex[i]>=65 && hex[i]<=70) {
            result += (hex[i]-55)*std::pow(16,hex.length( )-i-1);
        } else if (hex[i]>=97 && hex[i]<=102) {
            result += (hex[i]-87)*std::pow(16,hex.length()-i-1);
        }
    }
    return result;
}

template<class T>
class NodoB
{
    public:
       int                  m_Grado;
       T                    m_Dato;
       NodoB<T>  *          m_Padre;
       list< NodoB<T> * >   m_Sons;

       NodoB(T d)
       {
           m_Dato = d;
           m_Grado = 0;
           m_Padre = 0;
       } 
};

template<class T>
class Binomial_Heap
{
     private:
       list< NodoB<T> * >  m_Roots;
       NodoB<T>         *  m_pMin;
     private:
       void Compactar(); // O(log(n))
       NodoB<T>  * Unir(NodoB<T> * p ,NodoB<T> * q );  // O(1)
       void Print(NodoB<T> * p);
       void save_ostream(std::ostream & o);
       void save_ostream(NodoB<T> * p, std::ostream & o);
     public:
      Binomial_Heap(){ };
      ~Binomial_Heap(){};
      /**************************************/
      void Insert(T d); // O(log(n))
      void Extrac_Min(); // O(log(n))
      void Delete(NodoB<T> * e); // O(log(n))
      void Decrease_Key(NodoB<T> * e, T val); // O(log(n))
      void Print(); 
      NodoB<T> * GetMin();// O(1)
      void Show_Dot(std::string filename);
      /**************************************/
};

template<class T>
void Binomial_Heap<T>::Insert(T d) // O(log(n))
{
    NodoB<T> * pNew = new NodoB<T>(d);
    typename std::list<NodoB<T> * >::iterator it = m_Roots.begin();
    for (; it != m_Roots.end(); it++)
    {
        if ((*it)->m_Grado >= 0) break;
    }
    m_Roots.insert(it,pNew);
    if (d < m_pMin->m_Dato) m_pMin = pNew;
    Compactar();
}

template<class T>
void Binomial_Heap<T>::Extrac_Min() // O(log(n))
{
    // O(log(n))
    typename list< NodoB< T>  * >::iterator it = m_pMin->m_Sons.begin();
    for(; it != m_pMin->m_Sons.end(); it++)
           m_Roots.push_front(*it);
    m_Roots.remove(m_pMin); // O(log(n))
    Compactar();  // O(logn)
        
     
}

template<class T>
void Binomial_Heap<T>::Delete(NodoB<T> * e) // O(log(n))
{
    Decrease_Key(e,m_pMin->m_Dato - 1);
    Extrac_Min();
}

template<class T>
void Binomial_Heap<T>::Decrease_Key(NodoB<T> * e, T val) // O(log(n))
{
    e->m_Dato = val;
    while(e->m_Padre && e->m_Padre->m_Dato  >  e->m_Dato)
    {
        swap( e->m_Dato,e->m_Padre->m_Dato);
        e = e->m_Padre;
    }

    
}

template<class T>
NodoB<T> * Binomial_Heap<T>::GetMin()// O(1)
{
    
    return m_pMin;
}


// Log(n)
template<class T>
void Binomial_Heap<T>::Compactar() // O(log(n))
{
    typename list< NodoB<T>  * >::iterator it = m_Roots.begin();
    int current_degree = 0;
    while (it != m_Roots.end())
    {
        //std::cout << "xd\n";
        //std::cout << (*it)->m_Dato;
        if(it != --m_Roots.end() && it != m_Roots.end())
        {
            //std::cout << "B\n";
            //NodoB<T> * p = *it;
            typename std::list< NodoB<T> *>::iterator q = std::next(it);
            //std::cout << (*it)->m_Grado;
            if ((*it)->m_Grado == current_degree && (*q)->m_Grado == current_degree)
            {
                //std::cout << "Uniendo\n";
                NodoB<T> * r = Unir(*it,*q);
                it = this->m_Roots.erase(it);
                it = this->m_Roots.erase(it);
                //std::cout << r->m_Dato;
                //Print(r);
                //Print();
                this->m_Roots.insert(it,r);
                it--;
                
                //Print();
                current_degree++;
            }
            else ++it;
        }
        else ++it;
        //std::cout << "A\n" << current_degree;
    }
    
}

// O(1)
template<class T>
NodoB<T>  * Binomial_Heap<T>::Unir(NodoB<T> * p , NodoB<T> * q ) // O(1)
{
    if (p->m_Dato < q->m_Dato)
    {
        NodoB<T>  * r = p;
        r->m_Grado++;
        r->m_Sons.push_front(q);
        return r;
    }
    else
    {
        NodoB<T>  * r = q;
        r->m_Grado++;
        r->m_Sons.push_front(p);
        return r;
    }
}

template<class T>
void Binomial_Heap<T>::Print()
{
    std::cout << "Min: " << m_pMin->m_Dato << '\n';
    for(auto e : m_Roots)
    {
        this->Print(e);
    }
    std::cout << "Se ha impreso\n";
}

template<class T>
void Binomial_Heap<T>::Print(NodoB<T> * p)
{
    std::cout << p->m_Dato << " " << p->m_Grado << std::endl;/*
    for(auto e : p->m_Sons)
    {
        Print(e);
    }*/
}

template <typename T>
void Binomial_Heap<T>::save_ostream(std::ostream & o)
{
    for(auto e : this->m_Roots)
    {
        std::ostringstream emem;
        emem << e;
        o << hex2dec(emem.str().substr(4,4))  << " [label = " << '"' << e->m_Dato << '"' << "];" << '\n';
        save_ostream(e,o);
    }
    typename std::list< NodoB<T> *>::iterator e = m_Roots.begin();
    for(; e != --m_Roots.end(); e++)
    {
        std::ostringstream emem;
        emem << *e;
        typename std::list< NodoB<T> *>::iterator it = std::next(e);
        if (it != m_Roots.end())
        {
            std::ostringstream itmem;
            itmem << *it;
            if (e != m_Roots.end())
            o << hex2dec(emem.str().substr(4,4)) << " -- "  << hex2dec(itmem.str().substr(4,4)) << ';' << '\n';
        }
    }
}

template <typename T>
void Binomial_Heap<T>::save_ostream(NodoB<T> * p, std::ostream & o)
{
    for(auto e : p->m_Sons)
    {
        std::ostringstream emem;
        emem << e;
        std::ostringstream pmem;
        pmem << p;
        o << hex2dec(emem.str().substr(4,4)) << " [label = "<< '"' << e->m_Dato << '"' << "];" << '\n';
        o << hex2dec(pmem.str().substr(4,4)) << " -- "  << hex2dec(emem.str().substr(4,4)) << ';' << '\n'; 
        save_ostream(e,o);
    }
}
template <typename T>
void Binomial_Heap<T>::Show_Dot(std::string filename)
{
        ofstream archivo;
        archivo.open("grafo.dot");
        archivo << "graph A{\n";
        save_ostream(archivo);
        archivo << "\n}";
        archivo.close();
        system("dot grafo.dot -o grafo.png -Tpng");
        system("grafo.png");
}
int main()
{
    srand(time(0));
    Binomial_Heap<int> my_heap;

    // for (int i = 0; i < 10; i++)
    // {
    //     my_heap.Insert(rand()%100);
    // }
    srand (10); 

    int j= 1000;
    Binomial_Heap<int>test;
    // test.Insert(4);
    // test.Insert(5);
    // test.Insert(6);

    // test.Add(rand()%i);
    for(int i=0;i<15;i++){
        int a=rand()%j;
        test.Insert(a);
        cout<< a<<endl;
    }
    test.Extrac_Min();
    test.Print();
    cout<<"El minimo es "<<my_heap.GetMin()->m_Dato<<endl;
    
    test.Show_Dot("binomial");
    system("pause");

    return 0;
}