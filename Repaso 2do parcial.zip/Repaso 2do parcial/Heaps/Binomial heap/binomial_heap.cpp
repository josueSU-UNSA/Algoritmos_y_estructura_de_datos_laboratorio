#include <iostream>
#include <fstream>
#include <list>
#include<conio.h>
using namespace std;
//----------------------------MEJOR IMPRESION--------------------------------

template <class T>
class NodoB
{
public:
    int m_Grado;
    T m_Dato;
    NodoB<T> *m_Padre;
    list<NodoB<T> *> m_Sons;
    bool m_Color;

    NodoB(T d)
    {
        m_Dato = d;
        m_Grado = 0;
        m_Padre = 0;
        m_Color = 0;
    }
};

template <class T>
class Binomial_Heap
{
private:
    list<NodoB<T> *> m_Roots;
    NodoB<T> *m_pMin;

private:
    void Compactar();                         // O(log(n))
    NodoB<T> *Unir(NodoB<T> *p, NodoB<T> *q); // O(1)
    void PrintRaices(typename list<NodoB<T> *>::iterator it, typename list<NodoB<T> *>::iterator end, ofstream &archivo);
    void PrintArbol(NodoB<T> *, ofstream &archivo);
    NodoB<T>* mergeBinomialTrees(NodoB<T> *b1, NodoB<T> *b2);
public:
    Binomial_Heap(){};
    ~Binomial_Heap(){};
    /**************************************/
    void Insert(T d);                      // O(1))
    void Extrac_Min();                     // O(log(n))
    void Delete(NodoB<T> *e);              // O(log(n))
    void Decrease_Key(NodoB<T> *e, T val); // O(1)
    NodoB<T> *GetMin();                    // O(1)
    void Show_Dot(string filename);
};

template <class T>
void Binomial_Heap<T>::Insert(T d)
{
    NodoB<T> *pNew = new NodoB<T>(d);
    if(m_Roots.empty()){
        m_Roots.push_front(pNew);
        m_pMin=pNew;
        return ;
    }
    m_Roots.push_front(pNew);
    if (d < m_pMin->m_Dato)
    {
        m_pMin = pNew;
    }
    cout<<"insertando "<<pNew->m_Dato<<endl;
    Compactar();
}

template <class T>
void Binomial_Heap<T>::Extrac_Min() // O(log(n))
{
    typename list<NodoB<T> *>::iterator it=m_pMin->m_Sons.begin();
    cout<<"El valor minimo es "<<m_pMin->m_Dato<<endl;
    for(; it != (m_pMin->m_Sons).end(); it++){
        (*it)->m_Padre=NULL;
        //cout<<"grado del hijo "<<(*it)->m_Grado<<endl;
        m_Roots.push_front(*it);
    }
    m_Roots.remove(m_pMin); // O(log(n))
    //Compactar();
    // this->Delete(m_pMin);

    // typename list< NodoB< T>  * >::iterator it2 = m_Roots.begin();
    // for(; it2 != m_Roots.end(); it2++){
    //     if((*(it2))->m_Dato<m_pMin->m_Dato){
    //         m_pMin=(*it2);
    //     }
    //     Compactar();
    // }
}

template <class T>
void Binomial_Heap<T>::Delete(NodoB<T> *e) // O(log(n))
{
    Decrease_Key(e,m_pMin->m_Dato - 1);
    Extrac_Min();
}

template <class T>
void Binomial_Heap<T>::Decrease_Key(NodoB<T> *e, T val) // O(1)
{
    e->m_Dato = val;
    while(e->m_Padre && e->m_Padre->m_Dato  >  e->m_Dato)
    {
        swap( e->m_Dato,e->m_Padre->m_Dato);
        e = e->m_Padre;
    }
}

template <class T>
NodoB<T> *Binomial_Heap<T>::GetMin() // O(1)
{
    return m_pMin;
}

// Log(n)
template<typename T>
NodoB<T>* Binomial_Heap<T>::mergeBinomialTrees(NodoB<T> *b1, NodoB<T> *b2)
{
    if (b1->m_Dato > b2->m_Dato)
        swap(b1, b2);
    b2->m_Padre = b1;
    b1->m_Sons.push_front(b2);
    b1->m_Grado++;
    return b1;
}

template <class T>
void Binomial_Heap<T>::Compactar() // O(log(n))
{
    if (m_Roots.size() <= 1)
        return ;
    list<NodoB<T>*> new_heap;
    typename list<NodoB<T>*>::iterator it1,it2,it3;
    it1 = it2 = it3 = m_Roots.begin(); 
    if (m_Roots.size() == 2)
    {
        it2 = it1;
        it2++;
        it3 = m_Roots.end();
    }
    else
    {
        it2++;
        it3=it2;
        it3++;
    }
    while (it1 != m_Roots.end())
    {
        if (it2 == m_Roots.end())
            it1++;
        else if ((*it1)->m_Grado < (*it2)->m_Grado)
        {
            it1++;
            it2++;
            if(it3!=m_Roots.end())
                it3++;
        }
        else if (it3!=m_Roots.end() &&
                (*it1)->m_Grado == (*it2)->m_Grado &&
                (*it1)->m_Grado == (*it3)->m_Grado)
        {
            it1++;
            it2++;
            it3++;
        }
        else if ((*it1)->m_Grado == (*it2)->m_Grado)
        {
            //Node *temp;
            //*it1 = Unir(*it1,*it2);
            *it1 = mergeBinomialTrees(*it1,*it2);
            it2 = m_Roots.erase(it2);
            if(it3 != m_Roots.end())
                it3++;
        }
    }
}

// O(1)
template <class T>
NodoB<T> *Binomial_Heap<T>::Unir(NodoB<T> *p, NodoB<T> *q) // O(1)
{
    if (p->m_Dato < q->m_Dato)
    {
        p->m_Grado += 1;
        p->m_Sons.push_front(q);
        q->m_Padre = p;
        m_Roots.remove(q);
        //q = NULL;
        return p;
    }
    q->m_Grado += 1;
    q->m_Sons.push_front(p);
    //p = NULL;
    p->m_Padre = q;
    m_Roots.remove(p);
    return q;
}

template <class T>
void Binomial_Heap<T>::Show_Dot(string filename)
{
    ofstream archivo;
    archivo.open(filename.c_str(), ios::out);
    archivo << "digraph binomialHeap {" << endl;
    archivo << "label= \"Binomial Heap\";" << endl;
    //archivo << "node [shape = record];" << endl;
    typename list<NodoB<T> *>::iterator it = m_Roots.begin();
    PrintRaices(it, m_Roots.end(), archivo);
    archivo << "}" << endl;
    system("dot -Tjpg -O binomial.dot");
    system("open binomial.dot.jpg");
}

template <class T>
void Binomial_Heap<T>::PrintRaices(typename list<NodoB<T> *>::iterator it, typename list<NodoB<T> *>::iterator end, ofstream &archivo)
{
    if (it == end)
    {
        return;
    }
    archivo<<"subgraph "<<(*it)->m_Dato<<"{ label = "<< (*it)->m_Dato<<" ;"<<endl;
    archivo << (*it)->m_Dato << "[label= " << (*it)->m_Dato << "];" << endl;
    PrintArbol(*it,archivo);
    if (((next(it, 1))) != end)
    {
        archivo<<"{rank=same; "<<(*it)->m_Dato<<"; "<<(*(next(it, 1)))->m_Dato<<"}";
        archivo << (*it)->m_Dato << " -> " << (*(next(it, 1)))->m_Dato << endl;
    }
    archivo<<"}"<<endl;
    PrintRaices((++it), end, archivo);
}

template<typename T>
void Binomial_Heap<T>::PrintArbol(NodoB<T> * nodo,ofstream &archivo){
    if(!nodo)
        return ;
    typename list<NodoB<T> *>::iterator it=nodo->m_Sons.begin();
    //cout<<endl<<"Mostrando hijos de "<<nodo->m_Dato<<endl;
    for(;it!= nodo->m_Sons.end();it++){
        //cout<<((*it)->m_Dato)<<"   ";
        archivo << nodo->m_Dato <<" -> "<< (*it)->m_Dato<<";"<< endl;
        PrintArbol((*it),archivo);
    }
}

int main()
{
    Binomial_Heap<int> bh;
    // bh.Insert(3);
    // bh.Insert(30);
    // bh.Insert(4);
    // bh.Insert(5);
    // bh.Insert(6);
    // bh.Insert(7);
    // bh.Insert(2);
    // bh.Insert(4);
    // bh.Insert(6);
    // bh.Insert(7);
    // bh.Insert(2);
    // bh.Insert(4);
    // for(int i=0;i<1000;i++){
    //     bh.Insert(i);
    // }
     srand (10); 

    int j= 1000;
    Binomial_Heap<int>test;
    // test.Insert(4);
    // test.Insert(5);
    // test.Insert(6);

    // test.Add(rand()%i);
    for(int i=0;i<5;i++)test.Insert(i);
    // {
    //     int a=rand()%j;
    //     test.Insert(a);
    //     cout<< a<<endl;
    // }
    test.Insert(220);
    
    // test.Extrac_Min();
    // bh.Extrac_Min();
    // bh.Insert(10);
    test.Show_Dot("binomial.dot");
    getch();
    return 1;

    // m_Roots  3 ->
    //
}
