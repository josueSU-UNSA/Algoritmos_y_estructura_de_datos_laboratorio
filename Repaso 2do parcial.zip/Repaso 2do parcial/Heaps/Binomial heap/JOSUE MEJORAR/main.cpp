#include<iostream>
#include<conio.h>
#include<list>
#include<vector>
using namespace std;

template<class T>
class NodoB//TOMAMOS AL NODO BINOMIAL COMO UN ARBOL BINOMIAL
{
    public:
       int                  m_Grado;//GRADO O NUMERO DE HIJOS DEL NODO
       T                    m_Dato;//EL DATO DEL NODO
       NodoB<T>            *m_Padre;//EL PADRE DE CADA NODO DE NUESTRO BINOMIAL TREE
       list<NodoB<T> *>     m_Sons;//UNA LISTA DE HIJOS YA Q CADA VEZ Q HAGAMOS
                                    //LA UNION ENTRE DOS NODOS BINOMIALES
                                    //UNO SE VOLVEDRA HIJO DEL OTRO

       NodoB(T d)
       {
           this->m_Dato = d;//INCIALIZAMOS EL DATO
           this->m_Grado= 0;//EL PUNTERO AL PADRE POR DEFECTO SERA NULL
           this->m_Padre = 0;//INCIALIZAMOS POR DEFECTO AL PADRE EN 0 YA Q ESTE 
                        //SE COLOCARA INCIALMENTE EN NUESTRA LISTA
       }

};
//EL NUMERO DE ARBOLES Q NECESITO PARA 
//ARMAR UN BINOMIAL HEAP
//CON N ELEMENTOS DE ENTRADA ES
//Log(2)n
template<class T>
class Binomial_Heap
{
    private:

        list<NodoB<T>*>     m_Roots;//NUESTRA LISTA DE BINOMIAL TREES
        NodoB<T>           *m_pMin;//EL PUNTERO AL ELEMENTO MINIMO
    private:
       void Compactar(); // O(log(n))
       NodoB<T>  * Unir(NodoB<T> * p ,NodoB<T> * q );  // O(1)
    public:
        Binomial_Heap(){ };
        ~Binomial_Heap(){};
        void print(list<NodoB<T>*>);
        void print();
      /**************************************/
        void Insert(T d); // O(log(n))
        void Extrac_Min(); // O(log(n))
        void Delete(NodoB<T> * e); // O(log(n))
        void Decrease_Key(NodoB<T> * e, T val); // O(log(n))
        NodoB<T> * GetMin();// O(1)
        NodoB<T>* mergeBinomialTrees(NodoB<T> *b1, NodoB<T> *b2);

        //void Show_Dot(string filename);
        /**************************************/
        
};


//--------INSERT O (Log n)--------------------
//INSERTA NODO DE GRADO 0 
//LLAMA A COMPACTAR
//Y COMPACTAR LLAMA VARIAS VECES A UNION
//PARA CUMPLIR LA PROPIEDAD DE GRADOS DIFERENTES
template<class T>
void Binomial_Heap<T>::Insert(T d) // O(log(n))
{
    NodoB<T> * pNew = new NodoB<T>(d);
    if (this->m_Roots.empty())
    {
        this->m_Roots.push_front(pNew);
        this->m_pMin=pNew;
        
    }
    else{
        m_Roots.push_front(pNew);
        if(pNew->m_Dato<this->m_pMin->m_Dato)this->m_pMin=pNew;
        Compactar();
    }
    cout<<"Se inserto "<<pNew->m_Dato<<endl;
    
    
}
// Log(n)
template<typename T>
NodoB<T>* Binomial_Heap<T>::mergeBinomialTrees(NodoB<T> *b1, NodoB<T> *b2)
{
    if (b1->m_Dato > b2->m_Dato)
        swap(b1, b2);
    b2->m_Padre = b1;
    b1->m_Sons.push_front(b2);
    b1->m_Grado++;
    return b1;
}
//--------------EXTRACT_MIN  O (Log n)--------------------
template<class T>
void Binomial_Heap<T>::Extrac_Min() // O(log(n))
{
    // O(log(n))
    //PROCEDIMIENTO
    //TODOS LOS HIJOS SUBEN A LA LISTA M P ROOTS Y COMPACTAMOS
    // if(this->m_pMin->m_Grado==0){//COMO EN ESTE IF NO LLAMAMOS A COMPACTAR ENTONCES 
    //     m_Roots.remove(this->m_pMin);
    // }
    typename list< NodoB< T>  * >::iterator it = this->m_pMin->m_Sons.begin();
    for(; it != m_pMin->m_Sons.end(); it++){//DEMORA O(K) PORQ TIENE K HIJOS
        // OJO VER ESTA PARTE 
        // (*it)->m_Padre=0;//COMO HACEMOS PUSH FRONT DE LOS HIJOS Y ELIMINAMOS EL PADRE NECESITAMOS Q ESTOS HIJOS AHORA NO TENGAN PADRES
        m_Roots.push_front(*it);
        this->m_Roots.begin()->m_Padre=0;
    }
    m_Roots.remove(m_pMin);
    delete(this->m_pMin);
    this->m_pMin=0;
    // typename list< NodoB< T>  * >::iterator it2 = this->m_Roots.begin();

    // for(; it2 != this->m_Roots.end(); it2++){//DEMORA O(K) PORQ TIENE K HIJOS
    //     // OJO VER ESTA PARTE 
    //     // (*it)->m_Padre=0;//COMO HACEMOS PUSH FRONT DE LOS HIJOS Y ELIMINAMOS EL PADRE NECESITAMOS Q ESTOS HIJOS AHORA NO TENGAN PADRES
        
    //     this->m_pMin=*it2;
    //     this->m_Roots.begin()->m_Padre=0;
    // }
    // O(log(n))
    Compactar();  // O(logn)

}

template<class T>
void Binomial_Heap<T>::Delete(NodoB<T> * e) // O(log(n))
{
    Decrease_Key(e,this->m_pMin->m_Dato - 1);//O(Log n)
    Extrac_Min();//O(Log n)
}

template<class T>
void Binomial_Heap<T>::Decrease_Key(NodoB<T> * e, T val) // O(log(n))
{
    // OJO COMO EL DECREASE KEY NO LLAMA AL COMPACTAR
    //CAMBIAREMOS EL MINIMO DESDE AQUI
    e->m_Dato = val;
    NodoB<T>*pAux=0;
    while(e->m_Padre && e->m_Padre->m_Dato  >  e->m_Dato)
    {
        swap( e->m_Dato,e->m_Padre->m_Dato);
        
        e = e->m_Padre;
    }
    if(e->m_Dato<this->m_pMin->m_Dato)this->m_pMin=e;//PONEMOS ESTO YA Q EL DECREASE KEY NO SE DA NECESARIAMENTE
                                                    //EN EL BINOMIAL TREE QUE CONTIENE EL PMIN
}

template<class T>
NodoB<T> * Binomial_Heap<T>::GetMin()// O(1)
{
    return this->m_pMin;
}


//-----------COMPACTAR Log(n)-----------------------------------------------------------------
//RECORE TODO EL HEAP PARA VER Q NO HAYA NODOS DEL MISMO GRADO
//SI ENCUENTRA DOS NODOS DEL MISMO GRADO
//LLAMA A UNION Y SE JUNTAN
template<class T>
void Binomial_Heap<T>::Compactar() // O(log(n))
{
    // typename list< NodoB< T>  * >::iterator it = this->m_Roots.begin();
    // for(;it!=m_Roots.end();it++){//recorro la lista
    // typename std::list< NodoB<T> *>::iterator it2 = std::next(it);
    //     if((*it)->m_Grado==(*it2)->m_Grado){//si un nodo tiene el mismo grado q otro une estos nodos
    //         Unir(*it,*(it2));
    //     }
    // }
    if (m_Roots.size() <= 1)
        return ;
    list<NodoB<T>*> new_heap;
    typename list<NodoB<T>*>::iterator it1,it2,it3;
    it1 = it2 = it3 = m_Roots.begin(); 
    if (m_Roots.size() == 2)
    {
        it2 = it1;
        it2++;
        it3 = m_Roots.end();
    }
    else
    {
        it2++;
        it3=it2;
        it3++;
    }
    while (it1 != m_Roots.end())
    {
        if (it2 == m_Roots.end())
            it1++;
        else if ((*it1)->m_Grado < (*it2)->m_Grado)
        {
            it1++;
            it2++;
            if(it3!=m_Roots.end())
                it3++;
        }
        else if (it3!=m_Roots.end() &&
                (*it1)->m_Grado == (*it2)->m_Grado &&
                (*it1)->m_Grado == (*it3)->m_Grado)
        {
            it1++;
            it2++;
            it3++;
        }
        else if ((*it1)->m_Grado == (*it2)->m_Grado)
        {
            //Node *temp;
            //*it1 = Unir(*it1,*it2);
            *it1 = mergeBinomialTrees(*it1,*it2);
            it2 = m_Roots.erase(it2);
            if(it3 != m_Roots.end())
                it3++;
        }
    }

}

//---------------UNION O(1)-------------------------------------------
//UNE UN ARBOL CON OTRO
template<class T>
NodoB<T>  *Binomial_Heap<T>:: Unir(NodoB<T> * p ,NodoB<T> * q ) // O(1)
{
    if(p->m_Dato<=q->m_Dato){
        p->m_Sons.push_front(q);
        p->m_Grado++;
        q->m_Padre=p;
        this->m_Roots.remove(q);
    }
    else{//CASO:if(q->m_Dato<=p->m_Dato) 
        q->m_Sons.push_front(p);
        q->m_Grado++;
        p->m_Padre=q;
        this->m_Roots.remove(p);
    }
    return 0;
}
template<class T>
void Binomial_Heap<T>::print(list<NodoB<T>*>pAux){
    if(pAux.empty())return;
    else{
        typename list< NodoB< T>  * >::iterator it =pAux.begin();
        for(;it!=this->m_Roots.end();it++)cout<<(*it)->m_Dato<<" de grado: "<<(*it)->m_Grado<<" [ "<<print((*it)->m_Sons) <<" ] " <<" ---> ";
    }
    
}
template<class T>
void Binomial_Heap<T>::print(){
    print(this->m_Roots);
    cout<<endl;
    
}
int main()
{
    // list<int>aux;
    // aux.push_back(1);
    // aux.push_back(2);
    // aux.push_back(3);
    // aux.push_back(4);
    // aux.push_back(5);
    // aux.push_back(6);
    // list<int>::iterator it;
    // cout<<"SI LA LISTA ESTA VACIA EL BEGIN ES IGUAL AL END?"<<endl;
    // cout<<*(aux.begin())<<endl;
    // cout<<*(aux.end())<<endl;
    // for(it=aux.begin();it!=aux.end();it++)cout<<"HELLO"<<endl;
    // cout<<"FINISH"<<endl;
    // Binomial_Heap<int>test;
    // test.Insert(4);
    Binomial_Heap<int>test;
    for(int i=0;i<16;i++)test.Insert(i);
    // test.Insert(1);
    // test.Insert(2);
    // test.Insert(3);
    // test.Insert(4);
    // test.Insert(5);

    test.print();
    cout<<"Hello"<<endl;
    getch();
    return 1;
}