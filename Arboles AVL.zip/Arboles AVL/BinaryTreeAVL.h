#include <iostream>
#include "Node.h"
using namespace std;
template<typename T>
class BinaryTreeAVL{
    private:
        Node<T>*m_pRoot;
        int Altura(Node<T>*pAux,int count){
            if(!pAux)return 0;
            else if(!pAux->m_pSig[0] and !pAux->m_pSig[0])return 1;
            else return 1+max(this->Altura(pAux->m_pSig[0],count++),this->Altura(pAux->m_pSig[1],count++));
        }
        void Add(T value,Node<T>*&pAux){
            if(!pAux){
                pAux=new Node<T>(value);
            }
            else if(pAux->value==value)return;
            else{
                Add(value,pAux->m_pSig[pAux->value<value]);
                pAux->FE=this->Altura(pAux->m_pSig[1],0)-this->Altura(pAux->m_pSig[0],0);
            }
            
        }
        void print (Node<T> *  p)
        {
            if(!p)return;
            cout<<p->value<<" , FE= "<<p->FE<<endl;
            print(p->m_pSig[0]);
            print(p->m_pSig[1]);
        }
        
    public:
        BinaryTreeAVL(){
            this->m_pRoot=0;
        }
        void Add(T value){
            this->Add(value,this->m_pRoot);
        }/*
        int Altura(){
            return this->Altura(this->m_pRoot,0);
        }*/
        void print(){
            this->print(this->m_pRoot);
        }
/*
        void RDD(Nodo<T> * & p){
           Nodo<T>*q=p->m_pSon[1];
           p->m_pSon[1]=q->m_pSon[0];
           q->m_pSon[0]=p;
        }
       void RII(Nodo<T> * & p)
       {
            Nodo<T>*q=p->m_pSon[1];
            p->m_pSon[1]=q->m_pSon[0];
            q->m_pSon[0]=p;
        }
      
       void RDI(Nodo<T> * & p)
       {
           Nodo<T>*q,*r;
           q=p->m_pSon[1];
           r=q->m_pSon[0];
           q->m_pSon[0]=r->m_pSon[1];
           p->m_pSon[1]=r->m_pSon[0];
           r->m_pSon[1]=q;
           r->m_pSon[0]=p;

       }
       void RID(Nodo<T> * & p)
        {
            Nodo<T>*q,*r;
            q=p->m_pSon[0];
            r=q->m_pSon[1];
            q->m_pSon[1]=r->m_pSon[0];
            p->m_pSon[0]=r->m_pSon[1];
            r->m_pSon[0]=q;
            r->m_pSon[1]=p;
            
        }





*/
};