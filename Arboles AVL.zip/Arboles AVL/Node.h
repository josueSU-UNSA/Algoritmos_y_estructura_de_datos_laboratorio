#include<iostream>
using namespace std;
template<typename T>
class Node{
    public:

        Node<T>*m_pSig[3];
        int FE;
        T value;

    public:

        Node(T value=0){
            this->value=value;
            this->m_pSig[0]=0;
            this->m_pSig[1]=0;
            this->m_pSig[2]=0;
            this->FE=0;
        }
};