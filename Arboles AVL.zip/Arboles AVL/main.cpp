#include<iostream>
#include<conio.h>
#include "BinaryTreeAVL.h"
using namespace std;
int main(){
    BinaryTreeAVL<int>test;
    test.Add(15);
    test.Add(7);
    test.Add(20);
    test.Add(24);
    test.Add(19);
    test.Add(28);
    test.Add(30);
    test.print();
    getch();
    return 0;
}
