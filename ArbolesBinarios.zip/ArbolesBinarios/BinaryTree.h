#include <iostream>
using namespace std;
template<typename T>
class Node

{
    public:

        T m_dato;
        Node<T> * m_pSig[2];

    public:
        Node(T d){
            m_dato = d; 
            m_pSig [0]= 0;
            m_pSig [1]= 0;
        } 
};

template<typename T>
class BinaryTree{

    private:
        Node<T>m_pRoot;
        

    public:
        void insert(){
            
        }
};