#include <iostream>
#include <conio.h>
using namespace std;

int main(){

    getch();
    return 0;
}