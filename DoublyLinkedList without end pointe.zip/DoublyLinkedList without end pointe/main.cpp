#include<iostream>
#include <conio.h>
#include "DoublyLinkedList.h"
using namespace std;

int main(){
    DoublyLinkedList<int> test;
    test.pushBack(4);
    test.popBack();
    test.print();
    test.pushBack(7);
    test.pushBack(15);
    test.pushBack(8);
    test.pushBack(1);
    test.pushBack(9);
    test.pushBack(14);
    test.print();
    

    /*test.printRecursivoInicioFin();
    test.printReverseWithEnd();
    test.printReverseWithoutEnd();*/
    test.printRecursivoFinInicio();
    cout<<endl;
    //test.sort();
    test.print();
    //test.sortReverse();
    //test.print();
    getch();
    return 0;
}