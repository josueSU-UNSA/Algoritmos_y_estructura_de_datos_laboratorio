template<typename T>
class Node{
    private:

        T value;
        Node<T>*next;
        Node<T>*prev;

    public:

    //        FIRMAS

        Node(T value=0);

        Node<T>* getNext()const;

        void setNext(Node<T>*next);

        Node<T>* getPrev()const;

        void setPrev(Node<T>*prev);

        T getValue()const;

        void setValue(T value);

        T operator *()const;

        void operator =(T value);
    
};

//        DESARROLLO

template<typename T>
Node<T>::Node(T value){

    this->value=value;
    this->next=nullptr;
    this->prev=nullptr;

}

template<typename T>
Node<T>* Node<T>::getNext()const{
    return this->next;
}

template<typename T>
void Node<T>::setNext(Node<T>*next){
    this->next=next;
}

template<typename T>
Node<T>* Node<T>::getPrev()const{
    return this->prev;
}

template<typename T>
void Node<T>::setPrev(Node<T>*prev){
    this->prev=prev;
}

template<typename T>
T Node<T>::getValue()const{
    return this->value;
}

template<typename T>
void Node<T>::setValue(T value){
    this->value=value;
}

template<typename T>
T Node<T>::operator *()const{
    return this->value;
}

template<typename T>
void Node<T>::operator =(T value){
    setValue(value);
}