#include<iostream>
#include <conio.h>
#include "DoublyLinkedList.h"
using namespace std;
//  REPASO DE METODOS DE ORDENAMIENTO

int main(){
    
    
    DoublyLinkedList<int>listaTest;
    listaTest.pushBack(7);
    listaTest.deleteFront();
    
    cout<<"Probando "<<endl;
    cout<<listaTest.getLongitud()<<endl;
    listaTest.print();
    cout<<endl;


    //cout<<"Aca comenzamos a probar la insercion ordenada"<<endl;
    //(listaTest.find(77777)==true)?cout<<"Se encontro"<<endl:cout<<"No se encontro"<<endl;
    
    /*DoublyLinkedList<int>secondListTest;
    secondListTest.sortInsert(77);
    secondListTest.sortInsert(64);
    secondListTest.sortInsert(65);
    secondListTest.sortInsert(89);
    secondListTest.sortInsert(14);
    secondListTest.sortInsert(13);
    secondListTest.sortInsert(100);
    secondListTest.print();*/
    getch();
    return 0;

}