#include<iostream>
#include "Node.h"

//        DECLARACION DE LA CLASE DOUBLY_LINKED_LIST

template<typename T>
class DoublyLinkedList{
    private:

        Node<T>*head;
        Node<T>*end;
        int longitud;
    
    public:

    //          FIRMAS

        //Constructor por defecto
        DoublyLinkedList();

        //Constructor incializado con un numero
        DoublyLinkedList(T nodo);

        //Metodo que retornara la longitud de la lista
        int getLongitud();

        //Agregar al ultimo
        void pushBack(T nodo);

        //Borrar el ultimo
        void deleteBack();

        //Agregar al principio
        void pushFront(T nodo);

        //Borrar el inicio
        void deleteFront();

        void sortInsert(T);

        bool find(T);

        bool doubleFind(T);
        //Busca un elemento por indice
        int findIndex(T);

        //Metodo que retorna la direccion del primer nodo
        Node<T>*Begin();

        //Metodo que retorna la direccion del ultimo nodo o anterior a la cola
        Node<T>*End();

        //Sobrecarga del operador de indexacion 
        //Este retorna un objeto con el fin de 
        //Utilizar dicho efecto posteriormente 
        //para posteriormente hace un cambio basico 
        //como lo seria DoublyLinkedList[Indice]=T value
        Node<T>& operator [](int num);

        //Metodo que permitira ordenar la lista 
        void sort();

        //Metodo que permite imprimir la lista
        void print();

        //Metodo que permite imprimir la lista en orden contrario
        void printReverse();

};

//      IMPLEMENTACION DE LOS METODOS

template<typename T>
DoublyLinkedList<T>::DoublyLinkedList(){

    this->head=nullptr;
    this->end=head;
    this->longitud=0;

}

template<typename T>
DoublyLinkedList<T>::DoublyLinkedList(T nodo){
            
    this->head=new Node<T>(nodo);
    this->end=head;
    this->longitud=1;

}

template<typename T>
int DoublyLinkedList<T>::getLongitud(){
    return this->longitud;
}

template<typename T>
void DoublyLinkedList<T>::pushBack(T nodo){

    if(!this->head){

        this->head=new Node<T>(nodo);
        this->end=head;

    }

    else{

        this->end->setNext(new Node<T>(nodo));
        this->end->getNext()->setPrev(this->end);
        this->end=this->end->getNext();

    }

        this->longitud++;

}

template<typename T>
void DoublyLinkedList<T>::deleteBack(){

    if(head==nullptr){
        return;
    }

    else{

        this->end=end->getPrev();
        this->end->setNext(nullptr);
        delete this->end->getNext();
        this->longitud--;

    }

}


template<typename T>
void DoublyLinkedList<T>::pushFront(T nodo){

    if(!head){

        this->head=new Node<T>(nodo);
        this->end=head;

    }

    else{

        this->head->setPrev(new Node<T>(nodo));
        this->head->getPrev()->setNext(this->head);
        this->head=this->head->getPrev();

    }
        this->longitud++;

}

template<typename T>
void DoublyLinkedList<T>::deleteFront(){

    if(head==nullptr){
        return;
    }

    else if(this->longitud==1){
        delete this->head;
        this->head=nullptr;
        this->end=head;
        this->longitud--;
    }

    else{

        this->head=head->getNext();
        delete this->head->getPrev();
        this->head->setPrev(nullptr);
        this->longitud--;

    }

}

template<typename T>
void DoublyLinkedList<T>::sortInsert(T value){
    
    if(this->head==nullptr){
        this->head=new Node<T>(value);
        this->end=this->head;
    }

    else{

        if(this->head->getValue()>value){
/*
            if(value>=head->getValue()){
                this->head->setNext(new Node<T>(value));
                this->head->getNext()->setPrev(this->head);
            }
*/
            this->head->setPrev(new Node<T>(value));
            this->head->getPrev()->setNext(this->head);
            this->head=this->head->getPrev();
        }
        else{
            
            Node<T>*aux=this->head;

            while(aux->getNext() && value>aux->getValue()){
                aux=aux->getNext();
            }
            if(aux->getNext()){
                aux->getNext()->setPrev(new Node<T>(value));
                aux->getNext()->getPrev()->setNext(aux->getNext());
                aux->setNext(aux->getNext()->getPrev());
                aux->getNext()->setPrev(aux);
                //aux->getNext()->setPrev()
            }
            else{
                aux->setNext(new Node<T>(value));
                aux->getNext()->setPrev(aux);
                this->end=aux->getNext();
            }

            }

        }

}

template<typename T>
bool DoublyLinkedList<T>::find(T value){

    Node<T>*aux=this->head;

    while(aux){

        if(aux->getValue()==value){
            return true;
        }

        aux=aux->getNext();

    }

    return false;

}

/*
template<typename T>
bool DoublyLinkedList<T>::doubleFind(T value){
    
    if(!this->head){
        return false;
    }

    Node<T>**l=&this->head;
    Node<T>**r=&this->end;

    while(l!=r){

        if((*l)->getValue()==value||(*r)->getValue()==value){
            return true;
        }

        else if(*l==*r){
            return false
        }

        l=&((*l)->getNext());

        if(*l==*r){
            return false;
        }

        l=&((*l)->getNext());

        if(*l==*r){
            return false;
        }

        r=&((*r)->getNext());

    }
    return false;


}
*/
template<typename T>
bool DoublyLinkedList<T>::doubleFind(T value){

    Node<T>*auxL=this->head;
    Node<T>*auxR=this->end;
    if(auxL==auxR && auxL->getValue()==value){
        return true;
    }

    while(this->longitud>1){

        if(auxL==auxR && auxL->getValue()==value){
            return true;
        }

        else if(auxL==auxR && auxL->getValue()!=value){
            return false;
        }

        auxL=auxL->getNext();

        if(auxL->getValue()==value || auxR->getValue()==value){
            return true;
        }

        else if(auxL==auxR && auxL->getValue()==value){
            return true;
        }

        else if(auxL==auxR && auxL->getValue()!=value){
            return false;
        }

        auxR=auxR->getPrev();

    }

    return false;

}

template<typename T>
int DoublyLinkedList<T>::findIndex(T value){
    
    int count=0;
    Node<T>*aux=this->head;

    while(aux){

        if(aux->getValue()==value){
            return count;
        }
        aux=aux->getNext();
        count++;

    }

    return -1;

}

template<typename T>
Node<T>* DoublyLinkedList<T>::Begin(){
    return this->head;
}

template<typename T>
Node<T>* DoublyLinkedList<T>::End(){
    return this->end;
}

template<typename T>
Node<T>& DoublyLinkedList<T>::operator [](int num){

    if(num>=this->longitud){
        num=(num%longitud)-1;
    }

    else if (this->head==nullptr || num==0){
        return *(this->head);
    }

    else if(num==this->longitud-1){
        return *(this->end);
    }

    Node<T>*aux=this->head;

    for(int i=0;i<num;i++)
        aux=aux->getNext();

    return *(aux);

}

template<typename T>
void DoublyLinkedList<T>::sort(){

    Node<T> *aux1 = this->head;
    Node<T>*aux2=nullptr;
    T temp;

    while(aux1->getNext()){

        aux2 = aux1->getNext();

        while(aux2){

            if(aux2->getValue() < aux1->getValue()){

                temp = aux1->getValue();
                aux1->setValue(aux2->getValue());
                aux2->setValue(temp);

            }
            
            aux2 = aux2->getNext(); 
        
        }

        aux1 = aux1->getNext();

    }
}

template<typename T>
void DoublyLinkedList<T>::print(){

    Node<T>*aux=this->head;

    while (aux){

        std::cout<<"<-"<<aux->getValue()<<"->";
        aux=aux->getNext();

    }

    std::cout<<std::endl;

}

template<typename T>
void DoublyLinkedList<T>::printReverse(){

    Node<T>*aux=this->end;

    while (aux){

        std::cout<<"->"<<aux->getValue()<<"<-";
        aux=aux->getPrev();

    }

    std::cout<<std::endl;

}