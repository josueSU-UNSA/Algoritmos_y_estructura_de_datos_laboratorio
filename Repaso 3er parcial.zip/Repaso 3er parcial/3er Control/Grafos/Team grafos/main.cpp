// Practica Grafos.
// Juan Manuel Soto Begazo
// Fecha 06/12/2021

// 1. Implementar un grafo utilizando matriz de adyasencias etiquetada e implementar el algoritmo warshall y el algoritmo floyd.
// 2. Implementar un grafo Dirigido mediante lista de adyasencias, implemente añadir vértice, buscar vértice, añadir arista, e imprimir // un camino desde un vértice A hasta un Vértice B
// 3. Investigue e implemente un algoritmo para imprmir los nodos por  amplitud y por profundidad.

#include <iostream>
#include <list>
#include <vector>
#include <ostream>
#include <fstream>
using namespace std;

template <class V, class E>
class Vertex;

template <class V, class E>
class Edge
{
public:
    E m_Weigth;              // Peso de la arista
    Vertex<V, E> *m_pVertex; // Vertice
public:
    Edge(E d, Vertex<V, E> *p = 0)
    {
        m_Weigth = d;
        m_pVertex = p;
    }
    Edge(){};
};

template <class V, class E>
class Vertex
{
public:
    V m_Dato;                   // Nombre Vertice
    list<Edge<V, E>> m_Aristas; // Lista de Aristas que salen
public:
    Vertex(V d)
    {
        m_Dato = d;
        m_Aristas.clear();
    }
    Vertex(){};
};

template <class V, class E>
class Grafo
{
public:
    list<Vertex<V, E>> m_grafo; // Lista de Vetices
public:
    Grafo(){};
    Vertex<V, E> *find_Vertex(V v)
    {
        Vertex<V, E> *p = new Vertex<V, E>(v);
        if (m_grafo.empty())
            return 0;
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            if ((*it).m_Dato == p->m_Dato)
                return &(*it);
        }
        return p;
    }
    // void Insert_Vertex(V dato)
    // {
    //     Vertex<V,E> * p = find_Vertex(dato);
    //     if(p) return;
    //     m_grafo.push_back(*p);
    //     cout << "Insertando Vertice\n";
    // }

    void Insert_Vertex(V dato)
    {
        m_grafo.push_back(Vertex<V, E>(dato));
    }

    void Insert_Arista(V v1, V v2, E Ar)
    {
        Vertex<V, E> *p = find_Vertex(v1);
        Vertex<V, E> *q = find_Vertex(v2);
        if (p && q)
        {
            if (p == q)
            {
                cout << "No vale mano\n";
                return;
            }
            p->m_Aristas.push_back(Edge<V, E>(Ar, q));
        }
    }

    int index_vert(V nombre)
    {
        int index = 0;
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            if (nombre == (*it).m_Dato)
            {
                return index;
            }
            index++;
        }
        return 0;
    }

    vector<vector<int>> obtenerMatriz()
    {
        int size = m_grafo.size();
        int fil = 0;
        int col, peso;
        vector<vector<int>> matrix(size, vector<int>(size, 0));
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            typename ::list<Edge<V, E>>::iterator it_2 = (*it).m_Aristas.begin();
            for (; it_2 != (*it).m_Aristas.end(); it_2++)
            {
                col = index_vert((*it_2).m_pVertex->m_Dato);
                peso = (*it_2).m_Weigth;
                matrix[fil][col] = peso;
            }
            fil++;
        }
        return matrix;
    }

    void Warshall()
    {
        vector<vector<int>> M = obtenerMatriz();
        int n = M.size();
        for (int i = 0; i < n; i++)
        { // para movernos por las  filas
            for (int j = 0; j < n; j++)
            { // para movernos por las columnas
                for (int k = 0; k < n; k++)
                {                                              // para movernos por las columnas
                    M[i][j] = min(M[i][j], M[i][k] + M[k][j]); // SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                }
            }
        }
    }

    void Floyd()
    {
        vector<vector<int>> M = obtenerMatriz();
        int n = M.size();
        for (int i = 0; i < n; i++)
        { // para movernos por las  filas
            for (int j = 0; j < n; j++)
            { // para movernos por las columnas
                for (int k = 0; k < n; k++)
                {                                           // para movernos por las columnas
                    if (M[i][j] == 1 || M[i][k] && M[k][j]) // SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                        M[i][j] = 1;
                }
            }
        }
    }

    void Print()
    {
        for (auto a : m_grafo)
        {
            if (a.m_Aristas.empty())
                cout << "[" << a.m_Dato << "]\n";
            for (auto ver : a.m_Aristas)
            {
                cout << "[" << a.m_Dato << "]--------(" << ver.m_Weigth << ")-------->[" << ver.m_pVertex->m_Dato << "]\n";
            }
        }
    }

    void showDot(string file)
    {
        ofstream archivo;
        archivo.open(file.c_str(), ios::out);
        archivo << "digraph {\n";
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            if((*it).m_Aristas.empty()){
                archivo << (*it).m_Dato <<"\n";  
            }
            typename ::list<Edge<V, E>>::iterator it_2 = (*it).m_Aristas.begin();
            for (; it_2 != (*it).m_Aristas.end(); it_2++)
            {
                archivo << (*it).m_Dato << "->" << (*it_2).m_pVertex->m_Dato << "[ label=\""<<(*it_2).m_Weigth <<"\" ];\n";
            }
        }
        archivo << "}\n";
        archivo.close();
    }

    // void Print(ostrean & out);
};

int main()
{

    Grafo<string, int> G;
    G.Insert_Vertex("Arequipa"); // 0
    G.Insert_Vertex("Lima");     // 1
    G.Insert_Vertex("Cuzco");    // 2
    G.Insert_Vertex("Puno");     // 3
    G.Insert_Vertex("Ica");      // 4
    G.Insert_Vertex("Loreto");      // 4

    //   G.Print();
    //   cout << "fnaskfnaskfs\n";
    G.Insert_Arista("Arequipa", "Cuzco", 250);
    G.Insert_Arista("Arequipa", "Puno", 200);
    G.Insert_Arista("Lima", "Ica", 100);
    G.Insert_Arista("Lima", "Arequipa", 160);
    G.Print();
    G.showDot("grafo.dot");

    // vector<vector<int>> matrix = G.obtenerMatriz();
    // for (int i = 0; i < matrix.size(); i++)
    // {
    //     for (int j = 0; j < matrix.size(); j++)
    //     {
    //         cout << matrix[i][j] << " ";
    //     }
    //     cout << "\n";
    // }

    // vector<vector<int>> matrix(10, vector<int>(10, 5));
    // for (int i = 0; i < 10; i++)
    // {
    //     for (int j = 0; j < 10; j++)
    //     {
    //         cout << matrix[i][j] << " ";
    //     }
    //     cout << "\n";
    // }

    return 1;
}