#include <iostream>
#include <conio.h>
#include <list>
#include <vector>
#include <ostream>
#include <fstream>
#include "minHeap.cpp"
using namespace std;
/*
//ALGORITMO DE WARSHALL
//CON EL MOTIVO DE DARLE LA PONDERACION MINIMA
//PARA AQUELLAS RUTAS DIRECTAS E INDIRECTAS
//MATRIZ DE ADYACENCIA ETIQUETADA


//MATRIZ DE ADYACENCIA 
void Warshall(Matriz M,int n){
    for(int i=0;i<filas;i++){//para movernos por las  filas
        for(int i=0;i<filas;i++){//para movernos por las columnas
            for(int i=0;i<filas;i++){//para movernos por las columnas
                M[i][j]=min(M[i][j], M[i][k] && M[k][j])//SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES

        
            }
        
        }
    }
}



*/
/*
//ALGORITMO DE FLOYD
//MODIFICA TU PRIMERA MATRIZ DE ADYACENCIA 
//MODIFICA TU PRIMERA MATRIZ DE ADYACENCIA 
//AGREGANDO 1 HACIA AQUELLAS UNIONES
//directas e INDIRECTAS
void Floyd(Matriz M,int filas){
    for(int i=0;i<filas;i++){//para movernos por las  filas
        for(int i=0;i<filas;i++){//para movernos por las columnas
            for(int i=0;i<filas;i++){//para movernos por las columnas
                if(M[i][j]==1 || M[i][k]+M[k][j])//SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                    M[i][j]=1;
        
            }
        
        }
    }

}
*/

// void BFS(string file)
    // {
    //     ofstream archivo;
    //     vector<V>vertice;
    //     archivo.open(file.c_str(), ios::out);
    //     archivo << "digraph {\n";
    //     typename ::list<Vertex<V, E>>::iterator it = this->m_grafo.begin();
    //     for (; it != m_grafo.end(); it++)
    //     {
    //         if ((*it).m_Aristas.empty())
    //         {
    //             archivo << (*it).m_Dato << "\n";
    //            vertice.push_back((*it).m_Dato);
    //         }
            
    //     }
    //     archivo << "}\n";
    //     archivo.close();
    // }

//----------------------------ALGORITMOS DE IMPRESION ANCHO Y PROFUNDIDAD---------------------------------------------------
// Impresion por profundidad
    void dfs()
    {
        bool * visited = new bool[m_size];
        for (int i = 0; i < m_size; i++)
        {
            visited[i] = false;
        }
        typename std::list<Vertex<V,E>>::iterator it  = m_grafo.begin();
        visited[0] = true;
        std::cout << (*it).m_Dato << std::endl;
        for (auto e : (*it).m_Aristas)
        {
            dfs(e.m_pVertes,visited);
        }
    }
    // impresion por amplitud
    void bfs()
    {
        Queue<V> a;
        bool * visited = new bool[m_size];
        for (int i = 0; i < m_size; i++)
        {
            visited[i] = false;
        }
        visited[0] = true;
        typename std::list<Vertex<V,E>>::iterator it  = m_grafo.begin();
        a.add((*it).m_Dato);

        while(!a.is_empty())
        {
            Vertex<V,E>  * v = find_Vertex(a.peek());
            std::cout << a.peek() << ' ';
            a.remove();

            for (auto e : v->m_Aristas)
            {
                if(!visited[vert_pos(*(e.m_pVertes))])
                {
                    a.add((*e.m_pVertes).m_Dato);
                    visited[vert_pos(*(e.m_pVertes))] = true;
                }
            }
        }
        
    }
template <class V, class E>
class Vertex;

template <class V, class E>
class Edge
{
public:
    E m_Weigth;              // Peso de la arista
    Vertex<V, E> *m_pVertex; // Vertice
public:
    Edge(E d, Vertex<V, E> *p = 0)
    {
        m_Weigth = d;
        m_pVertex = p;
    }
    Edge(){};
};

template <class V, class E>
class Vertex
{
public:
    V m_Dato;
    list<Edge<V, E>> m_Aristas;
public:
    Vertex(V d)
    {
        m_Dato = d;
    }
    Vertex(){};
};
 
 
 template <class V, class E>
class Grafo
{
public:
    list<Vertex<V, E>> m_grafo; 
public:
    Grafo(){};
    Vertex<V, E> *findVertex(V v)
    {
        Vertex<V, E> *p = new Vertex<V, E>(v);
        if (m_grafo.empty())
            return 0;
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            if ((*it).m_Dato == p->m_Dato)
                return &(*it);
        }
        return p;
    }

    void insertVertex(V dato)
    {
        m_grafo.push_back(Vertex<V, E>(dato));
    }

    void insertArista(V v1, V v2, E Ar)
    {
        Vertex<V, E> *p = findVertex(v1);
        Vertex<V, E> *q = findVertex(v2);
        if (p && q)
        {
            if (p == q)return;
            p->m_Aristas.push_back(Edge<V, E>(Ar, q));
        }
    }

    
    void Warshall()
    {
        vector<vector<int>> M = getMatrix();
        int n = M.size();
        for (int i = 0; i < n; i++)
        { // para movernos por las  filas
            for (int j = 0; j < n; j++)
            { // para movernos por las columnas
                for (int k = 0; k < n; k++)
                {                                              // para movernos por las columnas
                    M[i][j] = min(M[i][j], M[i][k] + M[k][j]); // SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                }
            }
        }
    }

    void Floyd()
    {
        vector<vector<int>> M = getMatrix();
        int n = M.size();
        for (int i = 0; i < n; i++)
        { // para movernos por las  filas
            for (int j = 0; j < n; j++)
            { // para movernos por las columnas
                for (int k = 0; k < n; k++)
                {                                           // para movernos por las columnas
                    if (M[i][j] == 1 || M[i][k] && M[k][j]) // SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                        M[i][j] = 1;
                }
            }
        }
    }
    int indiceVertice(V nombre)
    {
        int index = 0;
        typename ::list<Vertex<V, E>>::iterator it = this->m_grafo.begin();
        for (; it != this->m_grafo.end(); it++)
        {
            if (nombre == (*it).m_Dato)
            {
                return index;
            }
            index++;
        }
        return 0;
    }

    vector<vector<int>> getMatrix()
    {
        int size = this->m_grafo.size();
        int fil = 0;
        int col, peso;
        vector<vector<int>> matrix(size, vector<int>(size, 0));
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            typename ::list<Edge<V, E>>::iterator it_2 = (*it).m_Aristas.begin();
            for (; it_2 != (*it).m_Aristas.end(); it_2++)
            {
                col = indiceVertice((*it_2).m_pVertex->m_Dato);
                peso = (*it_2).m_Weigth;
                matrix[fil][col] = peso;
            }
            fil++;
        }
        return matrix;
    }



    void showDot(string file)
    {
        ofstream archivo;
        archivo.open(file.c_str(), ios::out);//EL OUT ME LIMPIA EL .DOT CADA VEZ Q SOBREESCRIBIREMOS
        archivo << "digraph {\n";
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            if((*it).m_Aristas.empty()){
                archivo << (*it).m_Dato <<"\n";  
            }
            typename ::list<Edge<V, E>>::iterator it_2 = (*it).m_Aristas.begin();
            for (; it_2 != (*it).m_Aristas.end(); it_2++)
            {
                archivo << (*it).m_Dato << "->" << (*it_2).m_pVertex->m_Dato << "[ label=\""<<(*it_2).m_Weigth <<"\" ];\n";
            }
        }
        archivo << "}\n";
        archivo.close();
    }
    //----------------------ALGORITMOS MST GLOTON--------------------------
    
    void Kruskall(){

    }
};
 
 

int main()
 {
   Grafo<string, int> test;
   test.insertVertex("Madre_de_Dios");//NODOS AISLADOS
    test.insertVertex("Ucayali");//NODOS AISLADOS
    test.insertVertex("Huancavelica");//NODOS AISLADOS
    test.insertVertex("Arequipa"); 
    test.insertVertex("Chiclayo");     
    test.insertVertex("Junin");    
    test.insertVertex("Tacna");     
    test.insertVertex("Trujillo");      
    
    test.insertArista("Arequipa", "Junin", 100);
    test.insertArista("Arequipa", "Tacna", 150);
    test.insertArista("Chiclayo", "Trujillo", 400);
    test.insertArista("Chiclayo", "Arequipa", 225);
    
    test.showDot("grafo.dot");
   getch();
   return 0;
 }