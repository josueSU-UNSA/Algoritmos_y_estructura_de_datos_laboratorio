#include <iostream>
#include <conio.h>
#include <list>
#include <vector>
#include <ostream>
#include <fstream>
#include "minHeap.cpp"
using namespace std;
#define INF 999999999
/*
//ALGORITMO DE WARSHALL
//CON EL MOTIVO DE DARLE LA PONDERACION MINIMA
//PARA AQUELLAS RUTAS DIRECTAS E INDIRECTAS
//MATRIZ DE ADYACENCIA ETIQUETADA


//MATRIZ DE ADYACENCIA 
void Warshall(Matriz M,int n){
    for(int i=0;i<filas;i++){//para movernos por las  filas
        for(int i=0;i<filas;i++){//para movernos por las columnas
            for(int i=0;i<filas;i++){//para movernos por las columnas
                M[i][j]=min(M[i][j], M[i][k] && M[k][j])//SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES

        
            }
        
        }
    }
}



*/
/*
//ALGORITMO DE FLOYD
//MODIFICA TU PRIMERA MATRIZ DE ADYACENCIA 
//MODIFICA TU PRIMERA MATRIZ DE ADYACENCIA 
//AGREGANDO 1 HACIA AQUELLAS UNIONES
//directas e INDIRECTAS
void Floyd(Matriz M,int filas){
    for(int i=0;i<filas;i++){//para movernos por las  filas
        for(int i=0;i<filas;i++){//para movernos por las columnas
            for(int i=0;i<filas;i++){//para movernos por las columnas
                if(M[i][j]==1 || M[i][k]+M[k][j])//SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                    M[i][j]=1;
        
            }
        
        }
    }

}
*/

// void BFS(string file)
    // {
    //     ofstream archivo;
    //     vector<V>vertice;
    //     archivo.open(file.c_str(), ios::out);
    //     archivo << "digraph {\n";
    //     typename ::list<Vertex<V, E>>::iterator it = this->m_grafo.begin();
    //     for (; it != m_grafo.end(); it++)
    //     {
    //         if ((*it).m_Aristas.empty())
    //         {
    //             archivo << (*it).m_Dato << "\n";
    //            vertice.push_back((*it).m_Dato);
    //         }
            
    //     }
    //     archivo << "}\n";
    //     archivo.close();
    // }

//----------------------------ALGORITMOS DE IMPRESION ANCHO Y PROFUNDIDAD---------------------------------------------------
// Impresion por profundidad
    // void dfs()
    // {
    //     bool * visited = new bool[m_size];
    //     for (int i = 0; i < m_size; i++)
    //     {
    //         visited[i] = false;
    //     }
    //     typename std::list<Vertex<V,E>>::iterator it  = m_grafo.begin();
    //     visited[0] = true;
    //     std::cout << (*it).m_Dato << std::endl;
    //     for (auto e : (*it).m_Aristas)
    //     {
    //         dfs(e.m_pVertes,visited);
    //     }
    // }
    // // impresion por amplitud
    // void bfs()
    // {
    //     Queue<V> a;
    //     bool * visited = new bool[m_size];
    //     for (int i = 0; i < m_size; i++)
    //     {
    //         visited[i] = false;
    //     }
    //     visited[0] = true;
    //     typename std::list<Vertex<V,E>>::iterator it  = m_grafo.begin();
    //     a.add((*it).m_Dato);

    //     while(!a.is_empty())
    //     {
    //         Vertex<V,E>  * v = find_Vertex(a.peek());
    //         std::cout << a.peek() << ' ';
    //         a.remove();

    //         for (auto e : v->m_Aristas)
    //         {
    //             if(!visited[vert_pos(*(e.m_pVertes))])
    //             {
    //                 a.add((*e.m_pVertes).m_Dato);
    //                 visited[vert_pos(*(e.m_pVertes))] = true;
    //             }
    //         }
    //     }
        
    // }
template <class V, class E>
class Vertex;

template <class V, class E>
class Edge
{
public:
    E m_Weigth;              // Peso de la arista
    Vertex<V, E> *m_pVertex; // Vertice
public:
    Edge(E d, Vertex<V, E> *p = 0)
    {
        m_Weigth = d;
        m_pVertex = p;
    }
    Edge(){};
};

template <class V, class E>
class Vertex
{
public:
    V m_Dato;
    list<Edge<V, E>> m_Aristas;
public:
    Vertex(V d)
    {
        m_Dato = d;
    }
    Vertex(){};
};
 
 
 template <class V, class E>
class Grafo
{
public:
    list<Vertex<V, E>> m_grafo; 
public:
    Grafo(){};
    Vertex<V, E> *findVertex(V v)
    {
        Vertex<V, E> *p = new Vertex<V, E>(v);
        if (m_grafo.empty())
            return 0;
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            if ((*it).m_Dato == p->m_Dato)
                return &(*it);
        }
        return p;
    }

    void insertVertex(V dato)
    {
        m_grafo.push_back(Vertex<V, E>(dato));
    }

    void insertArista(V v1, V v2, E Ar)
    {
        Vertex<V, E> *p = findVertex(v1);
        Vertex<V, E> *q = findVertex(v2);
        if (p && q)
        {
            if (p == q)return;
            p->m_Aristas.push_back(Edge<V, E>(Ar, q));
        }
    }

    
    void Floyd()
    {
        vector<vector<int>> M = getMatrix();
        int n = M.size();
        for (int i = 0; i < n; i++)
        { // para movernos por las  filas
            for (int j = 0; j < n; j++)
            { // para movernos por las columnas
                for (int k = 0; k < n; k++)
                {                                              // para movernos por las columnas
                    M[i][j] = min(M[i][j], M[i][k] + M[k][j]); // SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                }
            }
        }
    }

    void Warshall()
    {
        vector<vector<int>> M = getMatrix();
        int n = M.size();
        for (int i = 0; i < n; i++)
        { // para movernos por las  filas
            for (int j = 0; j < n; j++)
            { // para movernos por las columnas
                for (int k = 0; k < n; k++)
                {                                           // para movernos por las columnas
                    if (M[i][j] == 1 || M[i][k]==1 && M[k][j]==1) // SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                        M[i][j] = 1;
                }
            }
        }
    }
    int indiceVertice(V nombre)
    {
        int index = 0;
        typename ::list<Vertex<V, E>>::iterator it = this->m_grafo.begin();
        for (; it != this->m_grafo.end(); it++)
        {
            if (nombre == (*it).m_Dato)
            {
                return index;
            }
            index++;
        }
        return 0;
    }

    vector<vector<int>> getMatrix()
    {
        int size = this->m_grafo.size();
        int fil = 0;
        int col, peso;
        vector<vector<int>> matrix(size, vector<int>(size, 0));
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            typename ::list<Edge<V, E>>::iterator it_2 = (*it).m_Aristas.begin();
            for (; it_2 != (*it).m_Aristas.end(); it_2++)
            {
                col = indiceVertice((*it_2).m_pVertex->m_Dato);
                peso = (*it_2).m_Weigth;
                matrix[fil][col] = peso;
            }
            fil++;
        }
        return matrix;
    }



    void showDot(string file)
    {
        ofstream archivo;
        archivo.open(file.c_str(), ios::out);//EL OUT ME LIMPIA EL .DOT CADA VEZ Q SOBREESCRIBIREMOS
        archivo << "digraph {\n";
        typename ::list<Vertex<V, E>>::iterator it = m_grafo.begin();
        for (; it != m_grafo.end(); it++)
        {
            if((*it).m_Aristas.empty()){
                archivo << (*it).m_Dato <<"\n";  
            }
            typename ::list<Edge<V, E>>::iterator it_2 = (*it).m_Aristas.begin();
            for (; it_2 != (*it).m_Aristas.end(); it_2++)
            {
                archivo << (*it).m_Dato << "->" << (*it_2).m_pVertex->m_Dato << "[ label=\""<<(*it_2).m_Weigth <<"\" ];\n";
            }
        }
        archivo << "}\n";
        archivo.close();
    }
    //----------------------ALGORITMOS MST GLOTON--------------------------
    
    void Kruskall(){

    }
};
 void Warshall(int M[][4],int n)
    {
        
        // int n = M.size();
        for (int i = 0; i < n; i++)
        { // para movernos por las  filas
            for (int j = 0; j < n; j++)
            { // para movernos por las columnas
                for (int k = 0; k < n; k++)
                {                                           // para movernos por las columnas
                    if (M[i][j] == 1 || (M[i][k]==1 && M[k][j]==1)) // SI HAY UN CAMINO DIRECTO O UN CAMINO INDIRECTO ENTONCES
                        M[i][j] = 1;
                }
            }
        }
    }
void floydWarshall(int graph[][4],int V)
{
    /* dist[][] will be the output matrix
    that will finally have the shortest
    distances between every pair of vertices */
    int i, j, k;
  
    
  
    /* Add all vertices one by one to
    the set of intermediate vertices.
    ---> Before start of an iteration,
    we have shortest distances between all
    pairs of vertices such that the
    shortest distances consider only the
    vertices in set {0, 1, 2, .. k-1} as
    intermediate vertices.
    ----> After the end of an iteration,
    vertex no. k is added to the set of
    intermediate vertices and the set becomes {0, 1, 2, ..
    k} */
    for (k = 0; k < V; k++) {
        // Pick all vertices as source one by one
        for (i = 0; i < V; i++) {
            // Pick all vertices as destination for the
            // above picked source
            for (j = 0; j < V; j++) {
                // If vertex k is on the shortest path from
                // i to j, then update the value of
                // dist[i][j]
                if(graph[i][j] > (graph[i][k] + graph[k][j])&& (graph[k][j] != INF && graph[i][k] != INF))
                    graph[i][j] = graph[i][k] + graph[k][j];//same than min(graph[i][j] || graph[i][k]+graph[k][j])
            }
        }
    }
  
}

int main()
 {
//    Grafo<string, int> test;
//    test.insertVertex("Madre_de_Dios");//NODOS AISLADOS
//     test.insertVertex("Ucayali");//NODOS AISLADOS
//     test.insertVertex("Huancavelica");//NODOS AISLADOS
//     test.insertVertex("Arequipa"); 
//     test.insertVertex("Chiclayo");     
//     test.insertVertex("Junin");    
//     test.insertVertex("Tacna");     
//     test.insertVertex("Trujillo");      
    
//     test.insertArista("Arequipa", "Junin", 100);
//     test.insertArista("Arequipa", "Tacna", 150);
//     test.insertArista("Chiclayo", "Trujillo", 400);
//     test.insertArista("Chiclayo", "Arequipa", 225);
    
    // test.showDot("grafo.dot");
    
    int matrixAdyBool[][4]={{0,1,0,0},{1,0,1,0},{0,0,0,1},{0,1,0,0}};
    int matrixAdyPond[][4]={{INF,11,27,INF},{INF,INF,15,INF},{27,10,INF,3},{INF,2,INF,INF}};
    floydWarshall(matrixAdyPond,4);
    Warshall(matrixAdyPond,4);
    // for(int i=0;i<4;i++){
    //     for(int j=0;j<4;j++){
    //         cout<<matrixAdyBool[i][j]<<" ";
    //     }   
    //     cout<<endl;
    // }
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            cout<<matrixAdyPond[i][j]<<" ";
        }   
        cout<<endl;
    }
   getch();
   return 0;
 }
 // 2. Implementar un grafo Dirigido mediante lista de adyasencias, implemente añadir vértice, buscar vértice, añadir arista, e imprimir // un camino desde un vértice A hasta un Vértice B
// #include <bits/stdc++.h>
// #include <string>
// #include <functional>

// using namespace std;


// template <class V, class E>
// class Edge; // prototipo declarado aqui para evitar error al usarlo en Vertex

// template <class V, class E>
// class Vertex // Clase vertice
// {
// public:
//     V m_Dato;   
//     bool visited;                 // Nombre del vertice
//     list<Edge<V, E>> m_Aristas; // Lista de objetos aristas que tienen un puntero a otro vertice
// public:
//     Vertex(V d ) : m_Dato{d} , visited{0} {}
//     Vertex() {}
//     ~Vertex() {}
// };

// template <class V, class E>
// class Edge
// {
// public:
//     E m_Dato;                // Nombre de arista
//     Vertex<V, E> *m_pVertex; // Puntero a otro vertice
// public:
//     Edge(E name, Vertex<V, E> *p = 0) : m_Dato{name}, m_pVertex{p} {}
//     Edge(){}
//     ~Edge(){}
// };

// template <class V, class E>
// class Arista
// {
// public:
//     E m_Dato;               
//     V vertex1;
//     V vertex2; 
// public:
//     Arista(E _name, V _vertex1 , V _vertex2) : m_Dato{_name}, vertex1{_vertex1} , vertex2{_vertex2} {}
// };

// template <class V, class E>
//     bool operator < (const Arista<V,E> &A1, const Arista<V,E> &A2)
//     {
//         return A1.m_Dato >  A2.m_Dato;
//     }

// template <class V, class E>
//     bool operator > (const Arista<V,E> &A1, const Arista<V,E> &A2)
//     {
//         return A1.m_Dato <  A2.m_Dato;
//     }

// template <class V, class E>
// ostream& operator << (ostream &o,const Arista<V,E> &p)
// {
//     o << "(" << p.m_Dato << ", " << p.vertex1 << ")";
//     return o;
// }

// template <class V, class E>
// class Grafo
// {
// private:
//     list<Vertex<V, E>> m_Grafo;
//     int tam = 0;
//     list<Arista<V, E>> m_Aristas;
//     vector<int> raices;
//     map<V,int> indices;
// public:
//     Grafo() {}

//     void insertarNodo(V valor)
//     {
//         Vertex<V, E> newNodo(valor);
//         tam++;
//         if (!existeNodo(newNodo)){
//             m_Grafo.push_back(newNodo);
//             raices.push_back(raices.size());
//             indices[valor] = raices.size(); 
//         }
//         else cout << "No se insertó. El nodo ya existe\n";
//     }
//     /////////////////////INSERTAR ARISTA////////////////////////
//     void insertarArista(V a, V b, E arista)
//     {
//         Vertex<V, E> * p = existeNodo(a);
//         Vertex<V, E> * q = existeNodo(b);
//         if (p && q)
//         {
//             if(!existeArista(p,q)) {
//                 p->m_Aristas.push_back(Edge<V, E>(arista, q));
//                 m_Aristas.push_back(Arista<V,E>(arista , a , b));
//             }
//         }
//         else 
//         {
//             cout<<"No existe algun vertice para insertar la arista";
//         }
//     }

//     bool existeArista(Vertex<V, E> * p,Vertex<V, E> * q)
//     {
//         for (auto it_3 = p->m_Aristas.begin(); it_3 != p->m_Aristas.end(); it_3++)
//         {
//             if ((*it_3).m_pVertex == q)
//             {
//                 return true;
//             }
//         }
//         return false;
//     }
    
   
//     /////////////////////ES VACIO////////////////////////
//     bool esVacio()
//     {
//         if (m_Grafo.empty())
//             return true;
//         return false;
//     }

//     /////////////////////EXISTE NODO////////////////////////
//     bool existeNodo(Vertex<V, E> p)
//     {
//         for (auto it = m_Grafo.begin(); it != m_Grafo.end(); it++)
//         {
//             if ((*it).m_Dato == p.m_Dato)
//                 return true;
//         }
//         return false;
//     }

//     Vertex<V, E> * existeNodo(V p)
//     {
//         for (auto it = m_Grafo.begin(); it != m_Grafo.end(); it++)
//         {
//             if ((*it).m_Dato == p)
//                 return &(*it);
//         }
//         return 0;
//     }

//     void verAdyacencia() // Imprime lista de adyacencias
//     {
//         for (auto it = m_Grafo.begin(); it != m_Grafo.end(); it++)
//         {
//             cout << (*it).m_Dato << " => ";
//             for (auto it_2 = (*it).m_Aristas.begin(); it_2 != (*it).m_Aristas.end(); ++it_2)
//             {
//                 // Descomentar para ver peso de arista
//                 // cout << (*it_2).m_pVertex->m_Dato << "(" << (*it_2).m_Dato << ")->"; 
//                 cout << (*it_2).m_pVertex->m_Dato << "->";
//             }
//             cout << endl;
//         }
//     }


//     int raiz(int x){
//         if(x == raices[x]) return x;
//         else return raiz(raices[x]);
        
//     }

//     void Union(int x, int y){
//         int x1,y1;
//         x1=raiz(x);
//         y1=raiz(y);
//         raices[x1]=y1;
//     }
    
//     bool ciclo(int x1 , int x2)
//     {
//         if(raiz(x1) == raiz(x2)) return true;
//         else return false;
//     }

//     Grafo<V,E> kruskal() //E log E
//     {
//         priority_queue< Arista<V,E>  , vector< Arista<V,E>> , less< Arista<V,E> > > H;
//         insert_priority(H);
//         Grafo<V,E> Tree;
//         int _V = tam;
//         int _E = 0;
//         cout<<H.top();
//         while(!H.empty() && _V > _E + 1 )
//         {
//             Arista<V,E> const& e = H.top();
//             int x = indices[e.vertex1];
//             int y = indices[e.vertex2];
//             if(!ciclo(x, y)) {
//                 Union (x , y);
//                 cout<<e.m_Dato;
//                 _E++;
//                 Tree.insertarNodo(e.vertex1);
//                 Tree.insertarNodo(e.vertex2);
//                 Tree.insertarArista(e.vertex1 , e.vertex2 , e.m_Dato);
//             }
//             H.pop();
//         }
//         return Tree;
//     }

//     void insert_priority(priority_queue< Arista<V,E>  , vector< Arista<V,E>> , less< Arista<V,E> > > & H) //E log E
//     {
//         for (auto it = m_Aristas.begin(); it != m_Aristas.end(); it++)
//         {
//             H.push(*it);
//             cout << (*it).vertex1 <<" ( "<<(*it).m_Dato <<" ) " << (*it).vertex2 <<endl;
//         }
        
    
//     }

//     void graficar()
//     {
//         ofstream arch;
//         arch.open("D:\\Graphviz\\bin\\graphL10.dot");
//         if (arch.is_open())
//         {
//             arch << "strict digraph A { \n";
//             for (auto it = m_Grafo.begin(); it != m_Grafo.end(); it++)
//             {
//                 arch << (*it).m_Dato << endl;
//                 for (auto it_2 = (*it).m_Aristas.begin(); it_2 != (*it).m_Aristas.end(); ++it_2)
//                 {
//                     // Descomentar para ver pesos de aristas
//                     arch << (*it).m_Dato << "->" << (*it_2).m_pVertex->m_Dato << "[label=" << (*it_2).m_Dato << "]" << endl;
//                     //arch << (*it).m_Dato << "->" << (*it_2).m_pVertex->m_Dato << endl;
//                 }
//             }
//             arch << "}\n";
//             arch.close();
//             system("dot -Tpng D:\\Graphviz\\bin\\graphL10.dot -o D:\\Graphviz\\bin\\graphL10.png ");
//             system("D:\\Graphviz\\bin\\graphL10.png ");
//         }
//         else
//         {
//             cout << "error al crear archivo";
//         }
//     }

// };

// int main()
// {

//     Grafo<int , int> G;
//     int a = 40;
//     for(int i = 1 ; i < a ;i++)
//     {
//         G.insertarNodo (i );
//     }

//     for(int i = 1 ; i < a ;i++)
//     {
//         G.insertarArista(i, i+1 , 3);
//     }

//     for(int i = 1 ; i < 10 ;i++)
//     {
//         G.insertarArista(1+rand()%(a-1), 1+rand()%(a-1), i);
//     }

//     Grafo<int , int> K = G.kruskal();
//     G.graficar();
//     cout<<endl;
    
//     return 0;
// }