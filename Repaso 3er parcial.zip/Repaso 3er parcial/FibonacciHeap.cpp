enum Color
{
    BLACK,
    WHITE
};
#include <iostream>
#include <fstream>
#include <istream>
#include <conio.h>
#include <list>
#include <limits.h>
using namespace std;

template <class T>
class NodoF
{
public:
    int m_Grado;
    T m_Dato;
    NodoF<T> *m_Padre;
    list<NodoF<T> *> m_Sons;
    bool m_Color;

    NodoF(T d)
    {
        m_Dato = d;
        m_Padre = 0;
        m_Color = WHITE;
    }
};

template <class T>
class Fibonaci_Heap
{
private:
    list<NodoF<T> *> m_Roots;
    NodoF<T> *m_pMin;

    NodoF<T> *Unir(NodoF<T> *p, NodoF<T> *q); // O(1)
    void fuuuuusioon(NodoF<T> *arreglo[], NodoF<T> *aux);
    NodoF<T> *mergeBinomialTrees(NodoF<T> *b1, NodoF<T> *b2);
    void Compactar(); // O(log(n))

public:
    Fibonaci_Heap()
    {
        m_pMin = 0;
    };
    ~Fibonaci_Heap(){};
    //-----OPERACIONES PRINCIPALES-----------------------
    void Insert(T d);                      // O(1))
    void Extract_Min();                    // O(log(n))
    void Delete(NodoF<T> *e);              // O(log(n))
    void Decrease_Key(NodoF<T> *e, T val); // O(1)
    NodoF<T> *GetMin();                    // O(1)

    //-------------IMPRESION-----------------------------
    void PrintArbol(NodoF<T> *, ofstream &archivo);

    void PrintRaices(typename list<NodoF<T> *>::iterator it, typename list<NodoF<T> *>::iterator end, ofstream &archivo);

    void Show_Dot(string filename);
    /**************************************/
};
//----------------------AUXILIARES FUNCIONAMIENTO----------
// O(1)
template <class T>
NodoF<T> *Fibonaci_Heap<T>::Unir(NodoF<T> *p, NodoF<T> *q) // O(1)
{
    if (p->m_Dato < q->m_Dato)
    {
        p->m_Grado += 1;
        p->m_Sons.push_front(q);
        q->m_Padre = p;
        m_Roots.remove(q);
        // q = NULL;
        return p;
    }
    q->m_Grado += 1;
    q->m_Sons.push_front(p);
    // p = NULL;
    p->m_Padre = q;
    m_Roots.remove(p);
    return q;
}
template <class T>

void Fibonaci_Heap<T>::fuuuuusioon(NodoF<T> *arreglo[], NodoF<T> *aux)
{
    if (arreglo[0] == 0)
    {
        arreglo[0] = aux;
        *(arreglo - 1) = 0;
        return;
    }
    NodoF<T> *algo = Unir(arreglo[0], aux);
    fuuuuusioon(arreglo + 1, algo);
    (*(arreglo - 1)) = 0;
}

template <typename T>
NodoF<T> *Fibonaci_Heap<T>::mergeBinomialTrees(NodoF<T> *b1, NodoF<T> *b2)
{
    if (b1->m_Dato > b2->m_Dato)
        swap(b1, b2);
    b2->m_Padre = b1;
    b1->m_Sons.push_front(b2);
    b1->m_Grado++;
    return b1;
}

template <class T>
void Fibonaci_Heap<T>::Compactar() // O(log(n))
{
    if (m_Roots.size() <= 1)
        return;

    typename list<NodoF<T> *>::iterator it = m_Roots.end();
    it--;
    int grado = (*it)->m_Grado + 3, indice;

    NodoF<T> *nodos[grado];
    // lo inicializamos con NULL para que no haya basura
    for (int i = 0; i < grado; i++)
    {
        nodos[i] = 0;
    }

    typename list<NodoF<T> *>::iterator it1;
    it1 = m_Roots.begin();

    for (; it1 != m_Roots.end(); it1++)
    {
        indice = (*it1)->m_Grado;
        if (nodos[indice] == 0)
        {
            nodos[indice] = (*it1);
        }
        else
        {
            fuuuuusioon(nodos + indice + 1, (Unir(nodos[indice], *it1)));
        }
    }
    m_Roots.clear();
    // cout << grado;
    for (int i = 0; i < grado; i++)
    {
        if (nodos[i] != 0)
        {
            m_Roots.push_back(nodos[i]);
        }
    }
}

//----------------OPERACIONES FIBONACCI HEAP-----------
template <class T>
void Fibonaci_Heap<T>::Insert(T d) // O(1)
{
    NodoF<T> *pNew = new NodoF<T>(d);
    if (this->m_Roots.empty())
    {
        this->m_pMin = pNew;
    }
    if (this->m_pMin->m_Dato > d)
        this->m_pMin = pNew;
    this->m_Roots.push_front(pNew);

    // Compactar();
}


template <class T>
void Fibonaci_Heap<T>::Extract_Min() // O(log(n))
{
    if (m_pMin)
    {
        return;
    }
    else if (m_pMin->m_Sons.end() == m_pMin->m_Sons.begin() )
    {
        m_Roots.remove(m_pMin);
        delete this->m_pMin;

        typename list<NodoF<T> *>::iterator it2 = m_Roots.begin();
        m_pMin = (*it2);
        for (; it2 != m_Roots.end(); it2++)
        {
            if ((*(it2))->m_Dato < m_pMin->m_Dato)
            {
                m_pMin = (*it2);
            }
        }
        // Compactar();
        return;
    }
    else
    {
        typename list<NodoF<T> *>::iterator it = m_pMin->m_Sons.end();
        it--;
        for (; it != (m_pMin->m_Sons).begin(); it--)
        {
            (*it)->m_Padre = NULL;
            (*it)->m_Color = 0;
            m_Roots.push_front(*it);
        }
        m_Roots.push_front(*it);
        m_Roots.remove(m_pMin);
        delete this->m_pMin;

        typename list<NodoF<T> *>::iterator it2 = m_Roots.begin();
        m_pMin = (*it2);
        for (; it2 != m_Roots.end(); it2++)
        {
            if ((*(it2))->m_Dato < m_pMin->m_Dato)
            {
                m_pMin = (*it2);
            }
        }
        // Compactar();
        return;
    }
}

template <class T>
void Fibonaci_Heap<T>::Delete(NodoF<T> *e) // O(log(n))
{
    Decrease_Key(e,INT_MIN);
    Extract_Min();
    Compactar();
}

// template <class T>
// void Fibonaci_Heap<T>::Decrease_Key(NodoF<T> *e, T val) // O(1)
// {
//     e->m_Dato = val;
//     while (e->m_Padre && e->m_Padre->m_Dato > e->m_Dato)
//     {
//         swap(e->m_Dato, e->m_Padre->m_Dato);
//         e = e->m_Padre;
//     }
// }

template <class T>
void Fibonaci_Heap<T>::Decrease_Key(NodoF<T> *e, T val) // O(1)
{
    
    if(e){
        NodoF<T>* n, *p;
        n = e;
        n->m_Dato = val;
        if(!n->m_Padre)return;
        if(n->m_Dato > n->m_Padre->m_Dato) return;
        
        do{
            p = n->m_Padre;
            p->m_Sons.remove(n);
            n->m_Color = WHITE;
            m_Roots.push_front(n);
            if(n->m_Dato < m_pMin->m_Dato){
                m_pMin = n;
            }
            n = p;
        }while(((p)&&(p->m_Color != WHITE)));
        if(p->m_Padre) p->m_Color = BLACK;
    }
}

template <class T>
NodoF<T> *Fibonaci_Heap<T>::GetMin() // O(1)
{
    return m_pMin;
}

template <typename T>
void Fibonaci_Heap<T>::PrintArbol(NodoF<T> *nodo, ofstream &archivo)
{
    if (!nodo)
        return;
    typename list<NodoF<T> *>::iterator it = nodo->m_Sons.begin();
    // cout<<endl<<"Mostrando hijos de "<<nodo->m_Dato<<endl;
    for (; it != nodo->m_Sons.end(); it++)
    {
        // cout<<((*it)->m_Dato)<<"   ";
        archivo << nodo->m_Dato << " -> " << (*it)->m_Dato << ";" << endl;
        PrintArbol((*it), archivo);
    }
}

template <class T>
void Fibonaci_Heap<T>::PrintRaices(typename list<NodoF<T> *>::iterator it, typename list<NodoF<T> *>::iterator end, ofstream &archivo)
{
    if (it == end)
    {
        return;
    }
    archivo << "subgraph " << (*it)->m_Dato << "{ label = " << (*it)->m_Dato << " ;" << endl;
    archivo << (*it)->m_Dato << "[label= " << (*it)->m_Dato << "];" << endl;
    PrintArbol(*it, archivo);
    if (((next(it, 1))) != end)
    {
        archivo << "{rank=same; " << (*it)->m_Dato << "; " << (*(next(it, 1)))->m_Dato << "}";
        archivo << (*it)->m_Dato << " -> " << (*(next(it, 1)))->m_Dato << endl;
    }
    archivo << "}" << endl;
    PrintRaices((++it), end, archivo);
}

template <class T>
void Fibonaci_Heap<T>::Show_Dot(string filename)
{
    ofstream archivo;
    archivo.open(filename.c_str(), ios::out);
    archivo << "digraph binomialHeap {" << endl;
    archivo << "label= \"Binomial Heap\";" << endl;
    // archivo << "node [shape = record];" << endl;
    typename list<NodoF<T> *>::iterator it = m_Roots.begin();
    PrintRaices(it, m_Roots.end(), archivo);
    archivo << "}" << endl;
    system("dot -Tjpg -O binomial.dot");
    system("open binomial.dot.jpg");
}

int main()
{
    Fibonaci_Heap<int> test;
    // test.Extract_Min();
    // for(int i=1;i<1000001;i++)test.Insert(i);

    for (int i = 1; i < 10; i++)
        test.Insert(i);
    
    // test.Decrease_Key(test.GetMin(),-1);

    test.Extract_Min();
    test.Show_Dot("Fibonacci.dot");
    getch();
    return 1;
}
