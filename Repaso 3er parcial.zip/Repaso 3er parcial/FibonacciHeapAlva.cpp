#include <iostream>
#include <fstream>
#include <list>
using namespace std;

template <class T>
class NodoB
{
public:
    int m_Grado;
    T m_Dato;
    NodoB<T> *m_Padre;
    list<NodoB<T> *> m_Sons;
    bool m_Color;

    NodoB(T d)
    {
        m_Dato = d;
        m_Grado = 0;
        m_Padre = 0;
        m_Color = 0;
    }
};

template <class T>
class Binomial_Heap
{
private:
    list<NodoB<T> *> m_Roots;
    NodoB<T> *m_pMin;
    void fuuuuusioon(NodoB<T> *arreglo [],NodoB<T> * aux){
        if(arreglo[0]==NULL){
            arreglo[0]=aux;
            *(arreglo-1)=NULL;
            return ;
        }
        NodoB<T>* algo=Unir(arreglo[0],aux);
        fuuuuusioon(arreglo+1,algo);
        (*(arreglo-1))=NULL;
    }

private:
    void Compactar();                         // O(log(n))
    NodoB<T> *Unir(NodoB<T> *p, NodoB<T> *q); // O(1)
    void PrintRaices(typename list<NodoB<T> *>::iterator it, typename list<NodoB<T> *>::iterator end, ofstream &archivo);
    void PrintArbol(NodoB<T> *, ofstream &archivo);
    NodoB<T> *mergeBinomialTrees(NodoB<T> *b1, NodoB<T> *b2);

public:
    Binomial_Heap(){};
    ~Binomial_Heap(){};
    /**************************************/
    void Insert(T d);                      // O(1))
    void Extrac_Min();                     // O(log(n))
    void Delete(NodoB<T> *e);              // O(log(n))
    void Decrease_Key(NodoB<T> *e, T val); // O(1)
    NodoB<T> *GetMin();                    // O(1)
    void Show_Dot(string filename);
};

template <class T>
void Binomial_Heap<T>::Insert(T d)
{
    NodoB<T> *pNew = new NodoB<T>(d);
    if (m_Roots.empty())
    {
        cout << "insertando " << pNew->m_Dato << endl;
        m_Roots.push_front(pNew);
        m_pMin = pNew;
        return;
    }
    m_Roots.push_front(pNew);
    if (d < m_pMin->m_Dato)
    {
        m_pMin = pNew;
    }
    cout << "insertando " << pNew->m_Dato << endl;
    Compactar();
}

template <class T>
void Binomial_Heap<T>::Extrac_Min() // O(log(n))
{
    typename list<NodoB<T> *>::iterator it = m_pMin->m_Sons.end();
    it--;
    for (; it != (m_pMin->m_Sons).begin(); it--)
    {
        (*it)->m_Padre = NULL;
        m_Roots.push_front(*it);
    }
    m_Roots.push_front(*it);
    m_Roots.remove(m_pMin);
    delete m_pMin;
    m_pMin=0;
    Compactar();
    // this->Delete(m_pMin);

    typename list<NodoB<T> *>::iterator it2 = m_Roots.begin();
    m_pMin = (*it2);
    for (; it2 != m_Roots.end(); it2++)
    {
        if ((*(it2))->m_Dato < m_pMin->m_Dato)
        {
            m_pMin = (*it2);
        }
    }
    cout << "El valor minimo es " << m_pMin->m_Dato << endl;
}

template <class T>
void Binomial_Heap<T>::Delete(NodoB<T> *e) // O(log(n))
{
    Decrease_Key(e, m_pMin->m_Dato - 1);
    Extrac_Min();
}

template <class T>
void Binomial_Heap<T>::Decrease_Key(NodoB<T> *e, T val) // O(1)
{
    e->m_Dato = val;
    while (e->m_Padre && e->m_Padre->m_Dato > e->m_Dato)
    {
        swap(e->m_Dato, e->m_Padre->m_Dato);
        e = e->m_Padre;
    }
}

template <class T>
NodoB<T> *Binomial_Heap<T>::GetMin() // O(1)
{
    return m_pMin;
}

template <class T>
void Binomial_Heap<T>::Compactar() // O(log(n))
{   
    if (m_Roots.size() <= 1)
        return;

    typename list<NodoB<T> *>::iterator it = m_Roots.end();
    it--;
    int grado = (*it)->m_Grado + 3, indice;

    NodoB<T> *nodos[grado];
    //lo inicializamos con NULL para que no haya basura
    for (int i = 0; i < grado; i++)
    {
        nodos[i] = NULL;
    }

    typename list<NodoB<T> *>::iterator it1;
    it1 = m_Roots.begin();

    for (; it1 != m_Roots.end(); it1++)
    {
        indice = (*it1)->m_Grado;
        if (nodos[indice] == NULL)
        {
            nodos[indice] = (*it1);
        }
        else
        {
            fuuuuusioon(nodos+indice+1,(Unir(nodos[indice], *it1)));
        }
    }
    m_Roots.clear();
    //cout << grado;
    for (int i = 0; i < grado; i++)
    {
        if (nodos[i] != NULL)
        {
            m_Roots.push_back(nodos[i]);
        }
    }
}

// O(1)
template <class T>
NodoB<T> *Binomial_Heap<T>::Unir(NodoB<T> *p, NodoB<T> *q) // O(1)
{
    if (p->m_Dato < q->m_Dato)
    {
        p->m_Grado += 1;
        p->m_Sons.push_front(q);
        q->m_Padre = p;
        //m_Roots.remove(q);
        //q = NULL;
        return p;
    }
    q->m_Grado += 1;
    q->m_Sons.push_front(p);
    //p = NULL;
    p->m_Padre = q;
    //m_Roots.remove(p);
    return q;
}

template <class T>
void Binomial_Heap<T>::Show_Dot(string filename)
{
    ofstream archivo;
    archivo.open(filename.c_str(), ios::out);
    archivo << "digraph binomialHeap {" << endl;
    archivo << "label= \"Binomial Heap\";" << endl;
    //archivo << "node [shape = record];" << endl;
    typename list<NodoB<T> *>::iterator it = m_Roots.begin();
    PrintRaices(it, m_Roots.end(), archivo);
    archivo << "}" << endl;
    system("dot -Tjpg -O binomial.dot");
    system("open binomial.dot.jpg");
}

template <class T>
void Binomial_Heap<T>::PrintRaices(typename list<NodoB<T> *>::iterator it, typename list<NodoB<T> *>::iterator end, ofstream &archivo)
{
    if (it == end)
    {
        return;
    }
    archivo << "subgraph " << (*it)->m_Dato << "{ label = " << (*it)->m_Dato << " ;" << endl;
    archivo << (*it)->m_Dato << "[label= " << (*it)->m_Dato << "];" << endl;
    PrintArbol(*it, archivo);
    if (((next(it, 1))) != end)
    {
        archivo << "{rank=same; " << (*it)->m_Dato << "; " << (*(next(it, 1)))->m_Dato << "}";
        archivo << (*it)->m_Dato << " -> " << (*(next(it, 1)))->m_Dato << endl;
    }
    archivo << "}" << endl;
    PrintRaices((++it), end, archivo);
}

template <typename T>
void Binomial_Heap<T>::PrintArbol(NodoB<T> *nodo, ofstream &archivo)
{
    if (!nodo)
        return;
    typename list<NodoB<T> *>::iterator it = nodo->m_Sons.begin();
    //cout<<endl<<"Mostrando hijos de "<<nodo->m_Dato<<endl;
    for (; it != nodo->m_Sons.end(); it++)
    {
        //cout<<((*it)->m_Dato)<<"   ";
        archivo << nodo->m_Dato << " -> " << (*it)->m_Dato << ";" << endl;
        PrintArbol((*it), archivo);
    }
}

int main()
{
    Binomial_Heap<int> bh;
    // bh.Insert(3);
    // bh.Insert(30);
    // bh.Insert(4);
    // bh.Insert(5);
    // bh.Insert(6);
    // bh.Insert(7);
    // bh.Insert(2);
    // bh.Insert(4);
    // bh.Insert(6);
    // bh.Insert(7);
    // bh.Insert(2);
    // bh.Insert(4);
    for (int i = 0; i < 100; i++)
    {
        bh.Insert(i);
    }
    
    bh.Extrac_Min();
    // bh.Insert(10);
    bh.Show_Dot("binomial.dot");
    return 1;

    // m_Roots  3 ->
    //
}
